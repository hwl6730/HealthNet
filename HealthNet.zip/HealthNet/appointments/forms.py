__author__ = 'Derek Popp'

from django import forms

from appointments.models import Appointment
from appointments.utils import check_overlap
from accounts.models import DoctorProfile, PatientProfile


class AppointmentForm(forms.ModelForm):
    title = forms.CharField(error_messages={'required': 'Please enter a title.'})
    start = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", '%Y-%m-%d %H:%M:%S'],
                                error_messages={'required': 'Please enter a starting date/time.'})
    end = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S'],
                              error_messages={'required': 'Please enter an ending date/time.'})
    doctor = forms.ModelChoiceField(queryset=DoctorProfile.objects.all(),
                                    error_messages={'required': 'Please select a doctor.'})
    patient = forms.ModelChoiceField(queryset=PatientProfile.objects.all(),
                                     error_messages={'required': 'Please select a patient.'})

    def is_valid(self, appt_id=None):

        # run parent validation first
        valid = super(AppointmentForm, self).is_valid()

        # if not valid, return
        if not valid:
            return valid

        # check for pesky time-travelers
        if self.cleaned_data['end'] < self.cleaned_data['start']:
            self._errors['time_travel'] = self.error_class(['End date cannot be before the start date.'])
            return False

        # good so far, check to see if appointment conflicts.
        for existing_appt in self.cleaned_data['doctor'].appointment_set.exclude(pk=appt_id):
            overlap = check_overlap(self.cleaned_data['start'], self.cleaned_data['end'],
                                    existing_appt.start, existing_appt.end)
            if overlap:
                self._errors['overlap'] = self.error_class(['Appointment overlaps with one already booked. ' +
                                                            'Please try a different time.'])
                return False

        return True

    class Meta:
        model = Appointment
        fields = {'title', 'start', 'end', 'doctor', 'patient'}
