__author__ = 'Derek Popp'

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, HttpResponse, Http404
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from appointments.models import Appointment
from action_logging.models import log_action, get_content_type
from appointments.forms import AppointmentForm
from appointments.utils import appointment_user_check


@login_required(login_url='/login')
def make_appt(request):
    """Adds an appointment to the system for a given patient and doctor"""
    user = User.objects.get(pk=request.user.id)
    context = RequestContext(request)
    if request.method == 'POST':
        if user.groups.filter(name='Patients').exists():
            aform = AppointmentForm(request.POST, initial={'patient': user.patientprofile.id})
            request.POST['patient'] = request.user.patientprofile.id
        elif user.groups.filter(name='Doctors').exists():
            aform = AppointmentForm(request.POST, initial={'doctor': user.doctorprofile.id})
            request.POST['doctor'] = request.user.doctorprofile.id
        else:
            aform = AppointmentForm(request.POST)

        if aform.is_valid():
            a = aform.save()
            a.save()

            log_action(user_id=user.id,
                       content_type_id=get_content_type(app_name='appointments', model_name='appointment').pk,
                       object_id=a.pk, object_desc='Patient \'%s\' and \'%s\' have scheduled appointment \'%s\'.'
                                                   % (a.patient, a.doctor, a), action_flag=1)

            return HttpResponseRedirect('/appointments/manage')
        else:
            if user.groups.filter(name='Patients').exists():
                return render_to_response('appointments/appointment.html', {'user': user, 'patient': user,
                                                                            'a_info': aform}, context)
            elif user.groups.filter(name='Doctors').exists():
                return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'doc_bool': True,
                                                                                        'doctor': user,
                                                                                        'a_info': aform}, context)
            elif user.groups.filter(name='Nurses').exists():
                return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'nurse': user,
                                                                                        'doc_bool': False,
                                                                                        'a_info': aform}, context)
    else:
        if user.groups.filter(name='Patients').exists():
            aform = AppointmentForm(initial={'doctor': user.patientprofile.doctor})
            return render_to_response('appointments/appointment.html', {'user': user, 'patient': user,
                                                                        'a_info': aform}, context)
        elif user.groups.filter(name='Doctors').exists():
            aform = AppointmentForm()
            return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'doctor': user,
                                                                                    'doc_bool': True,
                                                                                    'a_info': aform}, context)
        elif user.groups.filter(name='Nurses').exists():
            aform = AppointmentForm()
            return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'nurse': user,
                                                                                    'doc_bool': False,
                                                                                    'a_info': aform}, context)
        else:
            aform = None
            return HttpResponseRedirect('/')


@login_required(login_url='/login')
def manage_appt(request):
    user = request.user
    if user.groups.filter(name='Patients').exists():
        return render_to_response('appointments/manage_appointments.html', {'patient': user})
    elif user.groups.filter(name='Doctors').exists():
        doc_bool = True
        return render_to_response('appointments/staff/staff_manage_appointments.html', {'user': user, 'doctor': user,
                                                                                        'doc_bool': doc_bool})
    elif user.groups.filter(name='Nurses').exists():
        doc_bool = False
        apptSet = Appointment.objects.all()
        return render_to_response('appointments/staff/staff_manage_appointments.html', {'user': user, 'nurse': user,
                                                                                        'doc_bool': doc_bool,
                                                                                        'apptSet': apptSet})
    else:
        return HttpResponseRedirect('/')


@login_required(login_url='/login')
def edit_appt(request, appt_id):
    """Allows a user to change an appointment"""
    user = request.user
    if user.groups.filter(name='Doctors').exists():
        doc_bool = True
    else:
        doc_bool = False
    appt = Appointment.objects.get(pk=appt_id)
    context = RequestContext(request)
    if request.method == 'POST':
        if user.groups.filter(name='Patients').exists():
            aform = AppointmentForm(data=request.POST, instance=appt, initial={'patient': user.patientprofile})
        elif user.groups.filter(name='Doctors').exists():
            doc_bool = True
            aform = AppointmentForm(data=request.POST, instance=appt, initial={'doctor': user.doctorprofile})
        elif user.groups.filter(name='Nurses').exists():
            doc_bool = False
            aform = AppointmentForm(data=request.POST, instance=appt)
        else:
            aform = None

        if aform.is_valid(appt_id=appt_id):
            a = aform.save(commit=False)
            a.save()

            if doc_bool:
                log_action(user_id=user.id,
                           content_type_id=get_content_type(app_name='appointments', model_name='appointment').pk,
                           object_id=a.pk, object_desc='\'%s\' has edited their appointment \'%s\' with patient \'%s\'.'
                                                       % (user.doctorprofile, a, a.patient), action_flag=2)
            elif user.groups.filter(name='Patients').exists():
                log_action(user_id=user.id,
                           content_type_id=get_content_type(app_name='appointments', model_name='appointment').pk,
                           object_id=a.pk, object_desc='Patient \'%s\' has edited their appointment \'%s\' with \'%s\'.'
                                                       % (user.patientprofile, a, a.doctor), action_flag=2)
            else:
                log_action(user_id=user.id,
                           content_type_id=get_content_type(app_name='appointments', model_name='appointment').pk,
                           object_id=a.pk,
                           object_desc='\'%s\' has edited appointment \'%s\' with \'%s\' and patient \'%s\'.'
                                       % (user.nurseprofile, a, a.doctor, a.patient), action_flag=2)

            return HttpResponseRedirect('/appointments/manage')
        else:
            if user.groups.filter(name='Patients').exists():
                return render_to_response('appointments/appointment.html', {'user': user, 'patient': user,
                                                                            'a_info': aform}, context)
            elif user.groups.filter(name='Doctors').exists() or user.groups.filter(name='Nurses').exists():
                return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'nurse': user,
                                                                                        'doctor': user,
                                                                                        'doc_bool': doc_bool,
                                                                                        'a_info': aform}, context)
    else:
        if user.groups.filter(name='Patients').exists():
            aform = AppointmentForm(instance=appt)
            return render_to_response('appointments/appointment.html', {'user': user, 'patient': user,
                                                                        'a_info': aform}, context)
        elif user.groups.filter(name='Doctors').exists() or user.groups.filter(name='Nurses').exists():
            aform = AppointmentForm(instance=appt)
            return render_to_response('appointments/staff/staff_appointment.html', {'user': user, 'nurse': user,
                                                                                    'doctor': user,
                                                                                    'doc_bool': doc_bool,
                                                                                    'a_info': aform}, context)
        else:
            aform = None
            return render_to_response('appointments/appointment.html', {'user': user, 'doctor': user,
                                                                        'patient': user, 'nurse': user,
                                                                        'a_info': aform}, context)


@login_required(login_url='/login')
def delete_appt(request, appt_id):
    """Removes an appointment from the system"""
    a = get_object_or_404(Appointment, pk=appt_id)
    if not appointment_user_check(request.user, a):
        raise Http404

    log_action(user_id=request.user.id,
               content_type_id=get_content_type(app_name='appointments', model_name='appointment').pk,
               object_id=a.pk, object_desc='Patient \'%s\' and \'%s\' have removed appointment \'%s\'.'
                                           % (a.patient, a.doctor, a), action_flag=1)
    a.delete()
    return HttpResponseRedirect(reverse('manage_appts'))


@login_required(login_url='/login')
def appt_response(request, user_id):
    from appointments.utils import serialize_appointments

    user = request.user
    user_check = User.objects.get(id=user_id)
    if user != user_check:
        raise Http404

    if user.groups.filter(name='Patients').exists():
        appts = user.patientprofile.appointment_set.all()
        data = serialize_appointments(appts)
        return HttpResponse(data, content_type='application/json')
    elif user.groups.filter(name='Doctors').exists():
        appts = user.doctorprofile.appointment_set.all()
        data = serialize_appointments(appts)
        return HttpResponse(data, content_type='application/json')
    elif user.groups.filter(name='Nurses').exists():
        appts = Appointment.objects.all()
        data = serialize_appointments(appts)
        return HttpResponse(data, content_type='application/json')
    else:
        return HttpResponse([], content_type='application/json')
