__author__ = 'Derek Popp'
from django.conf.urls import patterns, url

from appointments.views import *


urlpatterns = patterns(
    '',

    url(r'^manage$', manage_appt, name='manage_appts'),
    url(r'^add$', make_appt, name='add_appt'),
    url(r'^del_appt/(?P<appt_id>\d+)/$', delete_appt, name='del_appt'),
    url(r'^edit/(?P<appt_id>\d+)/$', edit_appt, name='edit_appt'),
    url(r'^calendar/(?P<user_id>\d+)/appts', appt_response, name='appointment_data'),
)
