from datetime import datetime

from django.test import TestCase
from django.utils.timezone import get_current_timezone

from appointments.forms import AppointmentForm
from appointments.models import Appointment
from accounts.models import User, DoctorProfile, PatientProfile

# Create your tests here.


class AppointmentTestCase(TestCase):
    def setUp(self):  # make a dummy doctor and patient to create appointments
        self.u1 = User.objects.create_user(username='p1', password='x', first_name="Wade", last_name="Wilson")
        self.d1 = User.objects.create_user(username='d1', password='x', first_name="Stephen", last_name="Strange")
        self.dp1 = DoctorProfile.objects.create(user=self.d1)
        self.pp1 = PatientProfile.objects.create(user=self.u1, doctor=self.dp1, health_insurance="advkjsdfj",
                                                 ice_name="Mom", ice_phone="5555555555")
        # set up valid appointment for later use
        test_data = {'title': 'Test Appointment',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertTrue(appt_form.is_valid())
        tz = get_current_timezone()
        test_data['start'] = datetime.strptime(test_data['start'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        test_data['end'] = datetime.strptime(test_data['end'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        self.appt1 = appt_form.save()
        for key, value in test_data.items():
            if key == 'patient':
                self.assertEqual(getattr(self.appt1, key), self.pp1)
            elif key == 'doctor':
                self.assertEqual(getattr(self.appt1, key), self.dp1)
            else:
                self.assertEqual(getattr(self.appt1, key), value)

    def test_AppointmentForm_valid(self):
        test_data = {'title': 'Test Appointment',
                     'start': '2015-04-23 12:00:00',
                     'end': '2015-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertTrue(appt_form.is_valid())
        tz = get_current_timezone()
        test_data['start'] = datetime.strptime(test_data['start'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        test_data['end'] = datetime.strptime(test_data['end'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        appt = Appointment(**appt_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'patient':
                self.assertEqual(getattr(appt, key), self.pp1)
            elif key == 'doctor':
                self.assertEqual(getattr(appt, key), self.dp1)
            else:
                self.assertEqual(getattr(appt, key), value)

    def test_AppointmentForm_invalid_notitle(self):
        test_data = {'title': '',
                     'start': '2015-04-23 12:00:00',
                     'end': '2015-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertFalse(appt_form.is_valid())

    def test_AppointmentForm_invalid_longtitle(self):  # title > 200 characters
        test_data = {'title': 'x' * 205,
                     'start': '2015-04-23 12:00:00',
                     'end': '2015-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertFalse(appt_form.is_valid())

    def test_AppointmentForm_invalid_timetravel(self):  # starts in future, ends in past
        test_data = {'title': 'Appointment Test',
                     'start': '2015-04-23 12:00:00',
                     'end': '2015-04-20 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertFalse(appt_form.is_valid())

    def test_AppointmentForm_invalid_overlap(self):  # test for appointments that overlap
        test_data = {'title': 'Test Appointment',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertFalse(appt_form.is_valid())

    def test_AppointmentForm_valid_consecutiveappts(self):  # test for an appointment starting as one ends
        test_data = {'title': 'Test Appointment',
                     'start': '2099-04-23 13:00:00',
                     'end': '2099-04-23 14:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id}
        appt_form = AppointmentForm(test_data)
        self.assertTrue(appt_form.is_valid())

    def tearDown(self):
        del self.u1, self.d1, self.appt1, self.pp1, self.dp1