__author__ = 'Derek Popp'

import json
import datetime

from django.utils.timezone import localtime
from django.core.serializers.json import DjangoJSONEncoder

from accounts.models import DoctorProfile, PatientProfile


def appointment_user_check(user, appt):
    try:
        doctor = user.doctorprofile
        return doctor == appt.doctor
    except DoctorProfile.DoesNotExist:
        patient = None

    try:
        patient = user.patientprofile
        return patient == appt.patient
    except PatientProfile.DoesNotExist:
        return False


def serialize_appointments(appts):
    events = appts.values('id', 'title', 'start', 'end', 'allDay')
    data = json.dumps(list(events), default=encode_datetime, cls=DjangoJSONEncoder)
    return data


def encode_datetime(obj):
    if isinstance(obj, datetime.datetime):
        obj = localtime(obj)    # localize
        return obj.isoformat()
    else:
        return None


def check_overlap(appt1_start, appt1_end, appt2_start, appt2_end):
    if appt1_start > appt2_start:
        last_start = appt1_start
    else:
        last_start = appt2_start

    if appt1_end < appt2_end:
        first_end = appt1_end
    else:
        first_end = appt2_end

    if last_start < first_end:
        return True     # Appointments overlap
    else:
        return False    # Appointments do not overlap