__author__ = 'Derek Popp'

from django.db import models


class Appointment(models.Model):
    title = models.CharField(max_length=200)
    start = models.DateTimeField()
    end = models.DateTimeField()
    allDay = models.BooleanField(default=False)
    doctor = models.ForeignKey('accounts.DoctorProfile')
    patient = models.ForeignKey('accounts.PatientProfile')

    def __str__(self):
        return self.title