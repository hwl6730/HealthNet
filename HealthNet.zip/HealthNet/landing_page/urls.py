__author__ = 'Allen Sanford'

from django.conf.urls import patterns, url

from landing_page import views


urlpatterns = patterns('',
    url(r'^$', views.landing, name='landing'),
    url(r'^home/', views.index, name='patientHome')
)