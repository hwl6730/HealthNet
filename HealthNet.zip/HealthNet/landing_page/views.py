__author__ = 'Allen Sanford'

import datetime

from django.utils import timezone
from django.contrib.auth.models import User
from django.shortcuts import render
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from accounts.models import PatientProfile


def landing(request):
    return render(request, 'landing_page/landing.html')

@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def admin(request):
    """Loads the admin home"""
    current_user = request.user
    return render_to_response(
        'home/admin_home.html', {'user': current_user, 'timenow': datetime.datetime.now()},
    )


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists(), login_url='/home/')
@login_required(login_url='/login')
def doctor(request):
    """Loads the doctor home"""
    current_user = request.user
    return render_to_response(
        'home/doctor_home.html', {'doctor': current_user, 'timenow': datetime.datetime.now()},
    )

@user_passes_test(lambda u: u.groups.filter(name='Nurses').exists(), login_url='/home/')
@login_required(login_url='/login')
def nurse(request):
    """Loads the nurse home"""
    current_user = request.user
    return render_to_response(
        'home/nurse_home.html', {'nurse': current_user, 'timenow': datetime.datetime.now()},
    )


@login_required(login_url='/login')
def index(request):
    user = request.user

    if user.is_superuser:
        return HttpResponseRedirect('/staff/admin/')

    elif user.groups.filter(name='Patients').exists():
        if timezone.now() - user.date_joined <= datetime.timedelta(minutes=5):
            new_user = True
        else:
            new_user = False
        return render_to_response('home/patient_home.html', {'patient': user, 'new_user': new_user})
    elif user.groups.filter(name='Doctors').exists():
            return HttpResponseRedirect('/staff/doctor')
    elif user.groups.filter(name='Nurses').exists():
            return HttpResponseRedirect('/staff/nurse')
    else:
        return HttpResponseRedirect('/')


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists() or u.groups.filter(name='Nurses').exists(),
                  login_url='/home/')
@login_required(login_url='/login')
def patients(request):
    """Loads the list of patients for doctors and nurses"""
    u = User.objects.get(id=request.user.id)
    if u.groups.filter(name='Nurses').exists():
        patient_list = PatientProfile.objects.filter(hospital=u.nurseprofile.hospital.all())
        return render_to_response('staff_pages/nurse_patients.html', {'nurse': u, 'patients': patient_list},)
    else:
        patient_list = PatientProfile.objects.all()
        not_in_hospital = PatientProfile.objects.exclude(hospital=u.doctorprofile.hospital)

    paginator = Paginator(patient_list, 25)
    page = request.GET.get('page')

    try:
        patientlist = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        patientlist = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        patientlist = paginator.page(paginator.num_pages)

    return render(request, 'staff_pages/patients.html',
                  {'doctor': u, 'patients': patientlist, 'not_hos': not_in_hospital})


