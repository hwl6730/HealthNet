__author__ = 'Allen Sanford'

from django.forms import ModelForm

from admin.models import AdminProfile
from accounts.models import *
from accounts.forms import STATES, NATIONS, zip_regex, phone_regex

class NurseProfileForm(ModelForm):
    """Form for admins to create a NurseProfile"""
    class Meta:
        model = NurseProfile
        fields = ('hospital',)


class DoctorProfileForm(ModelForm):
    """Form for admins to create a DoctorProfile"""
    class Meta:
        model = DoctorProfile
        fields = ('hospital', 'nurses')


class HospitalProfileForm(ModelForm):
    """Form for admins to create a Hospital model"""
    name = forms.CharField(error_messages={'required': 'Please enter a Hospital name.'})
    address = forms.CharField(label='Address', error_messages={'required': "Please enter an address."})
    city = forms.CharField(error_messages={'required': 'Please enter your city.'})
    state = forms.ChoiceField(widget=forms.Select, choices=STATES,
                              error_messages={'required': 'Please enter your state.'})
    zipcode = forms.CharField(validators=[zip_regex], error_messages={'required': 'Please enter your zipcode.'})
    country = forms.ChoiceField(widget=forms.Select, choices=NATIONS,
                                error_messages={'required': 'Please enter your country.'})

    class Meta:
        model = Hospital
        fields = ('name', 'address', 'city', 'state',
                  'zipcode', 'country')


class AdminProfileForm(ModelForm):
    """Form for admins to create a Admin"""
    class Meta:
        model = AdminProfile
        fields = ('hospital',)
