from django.db import models
from django.contrib.auth.forms import *

from hospitals.models import Hospital


class AdminProfile(models.Model):
    user = models.OneToOneField(User)
    hospital = models.ManyToManyField(Hospital)

    def __str__(self):
        return "Admin " + self.user.first_name + ' ' + self.user.last_name