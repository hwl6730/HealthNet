from django.test import TestCase

from admin.forms import *
from admin.models import *


class DoctorProfileTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username="doc", password="pass")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_DoctorProfile_valid(self):
        test_data = {'hospital': self.hos.pk}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        del doc_profile_form.cleaned_data['nurses']
        doc_profile = DoctorProfile(**doc_profile_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'hospital':
                self.assertEqual(getattr(doc_profile, key), self.hos)
            else:
                self.assertEqual(getattr(doc_profile, key), value)

    def tearDown(self):
        del self.u1, self.hos


class NurseProfileTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username="nur", password="pass")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_NurseProfile_valid(self):
        test_data = {'hospital': [self.hos.pk, ]}
        nurse_profile_form = NurseProfileForm(test_data)
        self.assertTrue(nurse_profile_form.is_valid())
        del nurse_profile_form.cleaned_data['hospital'], test_data['hospital']
        nurse_profile = NurseProfile(**nurse_profile_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'hospital':
                self.assertEqual(getattr(nurse_profile, key), self.hos)
            else:
                self.assertEqual(getattr(nurse_profile, key), value)

    def tearDown(self):
        del self.u1, self.hos


class AdminProfileTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username="nur", password="pass")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_AdminProfile_valid(self):
        test_data = {'hospital': [self.hos.pk, ]}
        admin_profile_form = AdminProfileForm(test_data)
        self.assertTrue(admin_profile_form.is_valid())
        del admin_profile_form.cleaned_data['hospital'], test_data['hospital']
        admin_profile = AdminProfile(**admin_profile_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'hospital':
                self.assertEqual(getattr(admin_profile, key), self.hos)
            else:
                self.assertEqual(getattr(admin_profile, key), value)

    def tearDown(self):
        del self.u1, self.hos


class HospitalTestCase(TestCase):

    def test_HospitalForm_valid(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertTrue(hospital_form.is_valid())
        hospital = Hospital(**hospital_form.cleaned_data)
        for key, value in test_data.items():
            self.assertEqual(getattr(hospital, key), value)

    def test_HospitalForm_invalid_noname(self):
        test_data = {'name': '',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_noaddress(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_nocity(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': '',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_nostate(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': None,
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_nozip(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_zipshort(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '123',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_ziplong(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345678',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_zipletters(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': 'ab123',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())

    def test_HospitalForm_invalid_nocountry(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': None}
        hospital_form = HospitalProfileForm(test_data)
        self.assertFalse(hospital_form.is_valid())