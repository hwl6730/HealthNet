__author__ = 'Allen Sanford'

from django.conf.urls import patterns, url

from admin import views


urlpatterns = patterns('',
    url(r'^$', views.admin, name='admin_home'),
    url(r'^add/(?P<type_str>\w+)', views.add, name='admin_add'),
    url(r'^users/(?P<type_str>\w+)', views.users, name='admin_users'),
)