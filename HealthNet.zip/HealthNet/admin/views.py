__author__ = 'Allen Sanford'

from django.shortcuts import render_to_response, render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import user_passes_test
from django.template import RequestContext
from django.contrib.auth.models import Group
from django.contrib.admin.models import LogEntry
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from accounts.forms import *
from admin.forms import *
from action_logging.models import log_action, get_content_type


action_flag_dic = {
    1: 'ADDITION',
    2: 'CHANGE',
    3: 'DELETION',
    4: 'SYSTEM',
}


@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def admin(request):
    """Loads the admin home page when an Administrator logs in"""
    current_user = request.user

    log = LogEntry.objects.all()
    paginator = Paginator(log, 10)
    page = request.GET.get('page')

    try:
        logs = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        logs = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        logs = paginator.page(paginator.num_pages)

    return render(request, 'home/admin_home.html', {'user': current_user, 'logs': logs, 'flags': action_flag_dic})


@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def addHos(request):
    """Allows Administrators to add Hospitals to the system without using the admin panel"""
    context = RequestContext(request)

    registered = False

    postdata = request.POST.copy()

    if request.method == 'POST':
        special_form = HospitalProfileForm(data=request.POST)

        if special_form.is_valid():
            special_info = special_form.save(commit=False)
            special_info.save()

            return HttpResponseRedirect('/home')

    else:
        special_form = HospitalProfileForm()

    return render_to_response('admin/add.html', {'user': request.user, 'special_form': special_form, 'user_form': None,
                                                 'registered': registered}, context)


@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def add(request, type_str):
    """Allows Administrators to add users to the system without using the admin panel"""
    context = RequestContext(request)

    registered = False

    postdata = request.POST.copy()

    if request.method == 'POST':

        user_form = UserForm(data=request.POST)
        profile_form = UserProfileForm(data=request.POST)

        if type_str == "patient":
            special_form = PatientProfileForm(data=request.POST)

        elif type_str == "nurse":
            special_form = NurseProfileForm(data=request.POST)

        elif type_str == "admin":
            special_form = AdminProfileForm(data=request.POST)

        elif type_str == "doctor":
            special_form = DoctorProfileForm(data=request.POST)

        else:
            return addHos(request)

        if profile_form.is_valid() and user_form.is_valid() and special_form.is_valid():

            user = user_form.save(commit=False)
            user.set_password(user.password)
            user.save()

            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()

            special_info = special_form.save(commit=False)
            special_info.user = user

            special_info.save()

            g = None

            registered = True

            if type_str == "patient":
                g = Group.objects.get_or_create(name='Patients')

            elif type_str == "nurse":
                special_form.save_m2m()
                g = Group.objects.get_or_create(name='Nurses')

            elif type_str == "admin":
                special_form.save_m2m()
                user.is_superuser = True
                user.is_staff = True
                user.save()

            elif type_str == "doctor":
                special_form.save_m2m()
                g = Group.objects.get_or_create(name='Doctors')

            else:
                g = Group.objects.get_or_create(name='Hospitals')

            if g:
                group = g[0]
                group.user_set.add(user)

            log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                       object_id=user.id, object_desc='User \'%s\' has registered with HealthNet.' % user.username,
                       action_flag=1)

            return HttpResponseRedirect('/home')
    else:
        user_form = UserForm()
        profile_form = UserProfileForm()

        if type_str == "patient":
            special_form = PatientProfileForm()

        elif type_str == "nurse":
            special_form = NurseProfileForm()

        elif type_str == "admin":
            special_form = AdminProfileForm()

        elif type_str == "doctor":
            special_form = DoctorProfileForm()

        else:
            return addHos(request)

    return render_to_response('admin/add.html', {'user': request.user, 'special_form': special_form,
                                                 'user_form': user_form, 'profile_form': profile_form,
                                                 'registered': registered}, context)


@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def users(request, type_str):
    u_list = []
    u_type = None
    if type_str == "patients":
        u_list = PatientProfile.objects.all()
        u_type = "Patient"
    elif type_str == "doctors":
        u_list = DoctorProfile.objects.all()
        u_type = "Doctor"
    elif type_str == "nurses":
        u_list = NurseProfile.objects.all()
        u_type = "Nurse"
    elif type_str == "hospitals":
        u_list = Hospital.objects.all()
        u_type = "Hospital"
    else:  # admin
        u_list = AdminProfile.objects.all()
        u_type = "Admin"

    return render(request, 'admin/users.html', {'user': request.user, 'users': u_list, 'type': u_type})
