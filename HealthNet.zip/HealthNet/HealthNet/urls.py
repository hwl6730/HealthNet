__author__ = 'Allen Sanford', 'Derek Popp'

from django.conf.urls import patterns, include, url
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin

from accounts import views as account_views
from landing_page import views as lp_views
from prescriptions.views import *
from documents.views import *
from hospitals import views as hospital_views


admin.autodiscover()

urlpatterns = patterns(
    '',

    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', include('landing_page.urls')),
    url(r'^statistics/', include('stats.urls')),


    url(r'^login/', account_views.user_login),
    url(r'^register/', account_views.register),
    url(r'^home/$', lp_views.index),
    url(r'^logout/', account_views.logout),
    url(r'^appointments/', include('appointments.urls')),
    url(r'^messages/', include('messages.urls')),


    url(r'^home/medical/$', account_views.patient_med, name='patient_meds'),
    url(r'^home/change/$', account_views.change_info),

    url(r'^staff/admin/', include('admin.urls')),
    url(r'^staff/doctor/$', lp_views.doctor),
    url(r'^staff/nurse/$', lp_views.nurse),
    url(r'^staff/patients/$', lp_views.patients, name='staff_patients'),
    url(r'^staff/prescriptions/(\d+)/$', prescriptions),
    url(r'^staff/change/$', account_views.change_info),
    url(r'^staff/change/(?P<p_id>\d+)/$', account_views.change_info_staff, name='staff_change_user'),

    url(r'^staff/upload/(\d+)/$', upload),

    url(r'^staff/admit/(?P<p_id>\d+)/$', hospital_views.admit_patient),
    url(r'^staff/discharge/(?P<p_id>\d+)/$', hospital_views.discharge_patient),
    url(r'^staff/transfer/(?P<p_id>\d+)/$', hospital_views.transfer_patient, name="transfer_patient"),

    url(r'^p_delete/(?P<user_id>\d+)/(?P<prescrip_id>\d+)/$', delete_prescription, name='del_prescrip'),
    url(r'^doc_delete/(?P<user_id>\d+)/(?P<doc_id>\d+)/$', delete_doc, name='del_doc'),
    url(r'^doc_release/(?P<user_id>\d+)/(?P<doc_id>\d+)/$', release_doc, name='release_doc'),
    url(r'^doc_export/(?P<user_id>\d+)/$', export, name='doc_export'),

) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) \
    + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


