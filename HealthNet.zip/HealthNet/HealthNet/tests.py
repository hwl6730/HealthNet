from io import StringIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase

from accounts.forms import *
from admin.forms import *
from appointments.forms import AppointmentForm
from documents.forms import DocumentForm
from hospitals.forms import *
from messages.forms import MessageForm
from prescriptions.forms import *


# Integration tests


class UserIntegrationCase(TestCase):
    def setUp(self):
        test_data = {'username': 'p1',
                     'password': 'x',
                     'password_check': 'x',
                     'email': 'deadpool@marvel.com',
                     'first_name': "Wade",
                     'last_name': "Wilson"}
        user_form = UserForm(test_data)
        self.assertTrue(user_form.is_valid())
        self.user = user_form.save()
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_integration_User_UserProfile(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '14623',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertTrue(user_profile_form.is_valid())
        user_profile = user_profile_form.save(commit=False)

        user_profile.user = self.user
        user_profile.save()

        self.assertEqual(self.user, user_profile.user)
        self.assertEqual(self.user.userprofile, user_profile)

    def test_integration_User_PatientProfile(self):
        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.user = self.user
        patient_profile.save()

        self.assertEqual(self.user, patient_profile.user)
        self.assertEqual(self.user.patientprofile, patient_profile)

    def test_integration_User_DoctorProfile(self):
        test_data = {'hospital': None}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        doc_profile = doc_profile_form.save(commit=False)

        doc_profile.user = self.user
        doc_profile.save()

        self.assertEqual(self.user, doc_profile.user)
        self.assertEqual(self.user.doctorprofile, doc_profile)

    def test_integration_User_NurseProfile(self):
        test_data = {'hospital': [self.hos.pk, ]}
        nurse_profile_form = NurseProfileForm(test_data)
        self.assertTrue(nurse_profile_form.is_valid())
        nurse_profile = nurse_profile_form.save(commit=False)

        nurse_profile.user = self.user
        nurse_profile.save()

        self.assertEqual(self.user, nurse_profile.user)
        self.assertEqual(self.user.nurseprofile, nurse_profile)

    def test_integration_User_AdminProfile(self):
        test_data = {'hospital': [self.hos.pk, ]}
        admin_profile_form = AdminProfileForm(test_data)
        self.assertTrue(admin_profile_form.is_valid())
        del admin_profile_form.cleaned_data['hospital'], test_data['hospital']
        admin_profile = admin_profile_form.save(commit=False)

        admin_profile.user = self.user
        admin_profile.save()

        self.assertEqual(self.user, admin_profile.user)
        self.assertEqual(self.user.adminprofile, admin_profile)

    def tearDown(self):
        del self.user


class DoctorProfileIntegrationCase(TestCase):
    def setUp(self):
        test_data = {'hospital': None}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        self.doc = doc_profile_form.save(commit=False)
        self.user = User.objects.create_user(username="p1", password="pass")
        self.doc.user = self.user
        self.doc.save()
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_integration_DoctorProfile_PatientProfile(self):
        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.doctor = self.doc
        patient_profile.user = self.user
        patient_profile.save()

        self.assertEqual(self.doc, patient_profile.doctor)
        self.assertEqual(self.doc.patientprofile_set.all()[0], patient_profile)

    def test_integration_DoctorProfile_NurseProfile(self):
        test_data = {'hospital': [self.hos.pk, ]}
        nurse_profile_form = NurseProfileForm(test_data)
        self.assertTrue(nurse_profile_form.is_valid())
        nurse_profile = nurse_profile_form.save(commit=False)

        nurse_profile.user = self.user
        nurse_profile.save()
        self.doc.nurses.add(nurse_profile)
        self.doc.save()

        self.assertEqual(self.doc, nurse_profile.doctorprofile_set.all()[0])
        self.assertEqual(self.doc.nurses.all()[0], nurse_profile)

    def tearDown(self):
        del self.user, self.doc, self.hos


class HospitalIntegrationCase(TestCase):
    def setUp(self):
        test_data = {'name': 'Strong Memorial',
                     'address': '556 Nowhere You Know',
                     'city': 'Nowhere Town',
                     'state': 'TX',
                     'zipcode': '12345',
                     'country': 'USA'}
        hospital_form = HospitalProfileForm(test_data)
        self.assertTrue(hospital_form.is_valid())
        self.hospital = hospital_form.save()
        self.user = User.objects.create_user(username="p1", password="pass")

    def test_integration_Hospital_PatientProfile(self):
        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': self.hospital.pk}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.user = self.user
        patient_profile.save()

        self.assertEqual(self.hospital, patient_profile.hospital)
        self.assertEqual(self.hospital.patientprofile_set.all()[0], patient_profile)

    def test_integration_Hospital_DoctorProfile(self):
        test_data = {'hospital': self.hospital.pk}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        doc_profile = doc_profile_form.save(commit=False)

        doc_profile.user = self.user
        doc_profile.save()

        self.assertEqual(self.hospital, doc_profile.hospital)
        self.assertEqual(self.hospital.doctorprofile_set.all()[0], doc_profile)

    def test_integration_Hospital_NurseProfile(self):
        test_data = {'hospital': [self.hospital.pk, ]}
        nurse_profile_form = NurseProfileForm(test_data)
        self.assertTrue(nurse_profile_form.is_valid())
        nurse_profile = nurse_profile_form.save(commit=False)

        nurse_profile.user = self.user
        nurse_profile.save()
        nurse_profile.hospital.add(self.hospital)
        nurse_profile.save()

        self.assertEqual(self.hospital, nurse_profile.hospital.all()[0])
        self.assertEqual(self.hospital.nurseprofile_set.all()[0], nurse_profile)

    def test_integration_Hospital_AdminProfile(self):
        test_data = {'hospital': [self.hospital.pk, ]}
        admin_profile_form = AdminProfileForm(test_data)
        self.assertTrue(admin_profile_form.is_valid())
        del admin_profile_form.cleaned_data['hospital'], test_data['hospital']
        admin_profile = admin_profile_form.save(commit=False)

        admin_profile.user = self.user
        admin_profile.save()
        admin_profile.hospital.add(self.hospital)
        admin_profile.save()

        self.assertEqual(self.hospital, admin_profile.hospital.all()[0])
        self.assertEqual(self.hospital.adminprofile_set.all()[0], admin_profile)

    def test_integration_Hospital_Admission(self):
        u1 = User.objects.create_user(username='u1', password='x', first_name="Wade", last_name="Wilson")
        d1 = User.objects.create_user(username='d1', password='x', first_name="Stephen", last_name="Strange")
        dp1 = DoctorProfile.objects.create(user=d1)
        pp1 = PatientProfile.objects.create(user=u1, doctor=dp1, health_insurance="advkjsdfj",
                                            ice_name="Mom", ice_phone="5555555555")

        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': pp1.id,
                     'doctor': dp1.id,
                     'explanation': 'CC',
                     'hospital': self.hospital.id}
        add_form = AdmissionForm(test_data)
        self.assertTrue(add_form.is_valid())
        addm = add_form.save()

        self.assertEqual(self.hospital, addm.hospital)
        self.assertEqual(self.hospital.admission_set.all()[0], addm)

        del u1, d1, dp1, pp1

    def tearDown(self):
        del self.hospital, self.user


class PrescriptionIntegrationCase(TestCase):
    def setUp(self):
        from decimal import Decimal as D
        test_data = {
            'dosage': D('50'),
            'units': 'mg',
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertTrue(prescription_form.is_valid())
        self.prescription = prescription_form.save(commit=False)
        self.user = User.objects.create_user(username="p1", password="pass")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_integration_Prescription_DoctorProfile_PatientProfile(self):
        test_data = {'hospital': self.hos.id}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        doc_profile = doc_profile_form.save(commit=False)

        doc_profile.user = self.user
        doc_profile.save()

        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.user = self.user
        patient_profile.save()

        self.prescription.doctor = doc_profile
        self.prescription.patient = patient_profile
        self.prescription.save()

        self.assertEqual(self.prescription, doc_profile.prescription_set.all()[0])
        self.assertEqual(self.prescription, patient_profile.prescription_set.all()[0])
        self.assertEqual(self.prescription.doctor, doc_profile)
        self.assertEqual(self.prescription.patient, patient_profile)

    def tearDown(self):
        del self.prescription, self.hos, self.user


class AppointmentIntegrationCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="p1", password="pass")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_integration_Appointment_DoctorProfile_PatientProfile(self):
        test_data = {'hospital': self.hos.id}
        doc_profile_form = DoctorProfileForm(test_data)
        self.assertTrue(doc_profile_form.is_valid())
        doc_profile = doc_profile_form.save(commit=False)

        doc_profile.user = self.user
        doc_profile.save()

        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.user = self.user
        patient_profile.save()

        test_data = {'title': 'Test Appointment',
                     'start': '2015-04-23 12:00:00',
                     'end': '2015-04-23 13:00:00',
                     'patient': patient_profile.pk,
                     'doctor': doc_profile.pk}
        appt_form = AppointmentForm(test_data)
        self.assertTrue(appt_form.is_valid())
        self.appt = appt_form.save(commit=False)

        self.appt.patient = patient_profile
        self.appt.doctor = doc_profile
        self.appt.save()

        self.assertEqual(self.appt, patient_profile.appointment_set.all()[0])
        self.assertEqual(self.appt, doc_profile.appointment_set.all()[0])
        self.assertEqual(self.appt.patient, patient_profile)
        self.assertEqual(self.appt.doctor, doc_profile)

    def tearDown(self):
        del self.appt, self.hos, self.user


class DocumentIntegrationCase(TestCase):
    def setUp(self):
        self.imgfile = StringIO('GIF87a\x01\x00\x01\x00\x80\x01\x00\x00\x00\x00ccc,\x00'
                                '\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;')
        self.imgfile.name = 'test_img_file.gif'
        self.file = SimpleUploadedFile(self.imgfile.name, bytes(self.imgfile.read(), 'utf-8'), content_type='image/gif')
        self.user = User.objects.create_user(username="p1", password="pass")

    def test_integration_Document_PatientProfile(self):
        test_data = {'name': self.imgfile.name,
                     'comments': 'This is a file.'}
        file_data = {'docfile': self.file}
        doc_form = DocumentForm(test_data, file_data)
        self.assertTrue(doc_form.is_valid())
        upload = doc_form.save(commit=False)

        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = patient_profile_form.save(commit=False)

        patient_profile.user = self.user
        patient_profile.save()

        upload.patient = patient_profile
        upload.save()

        self.assertEqual(upload.patient, patient_profile)
        self.assertEqual(upload, patient_profile.document_set.all()[0])

    def tearDown(self):
        del self.imgfile.name, self.imgfile, self.file, self.user


class MessagingIntegrationCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="test1", password="pass", first_name="John", last_name="Doe")

    def test_integration_Messages_UserProfile(self):

        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '14623',
                     'country': "USA"}
        user = UserProfileForm(test_data)
        self.assertTrue(user.is_valid())
        user1 = user.save(commit=False)
        user1.user = self.user
        user1.save()

        test_data = {'recipient': self.user.id,
                     'subject': 'Test Subject',
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertTrue(msg_form.is_valid())
        msg = msg_form.save(commit=False)

        msg.sender = user1
        msg.recipient = user1
        msg.save()

        self.assertEqual(msg.sender, user1)
        self.assertEqual(msg.recipient, user1)
        self.assertEqual(msg, user1.received_messages.all()[0])
        self.assertEqual(msg, user1.sent_messages.all()[0])

    def tearDown(self):
        del self.user