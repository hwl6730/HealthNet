# from django.contrib.auth.models import Group
#
# patient = Group(name='Patient')
# patient.save()
# doctor = Group(name='Doctor')
# doctor.save()
# nurse = Group(name='Nurse')
# nurse.save()