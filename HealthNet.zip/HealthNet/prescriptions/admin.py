__author___='Derek Popp'
from django.contrib import admin

from prescriptions.models import Prescription


# Register your models here.
admin.site.register(Prescription)
