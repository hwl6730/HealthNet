__author__ = 'Derek'
from accounts.models import DoctorProfile


def prescription_user_check(user, prescription):
    try:
        doctor = user.doctorprofile
    except DoctorProfile.DoesNotExist:
        return False

    return doctor == prescription.doctor
