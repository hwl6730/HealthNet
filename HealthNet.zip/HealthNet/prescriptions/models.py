__author__ = 'Derek Popp'

from django.db import models


class Prescription(models.Model):
    dosage = models.DecimalField(max_digits=5, decimal_places=2)
    units = models.CharField(max_length=5)
    medicine = models.CharField(max_length=50, blank=True)
    notes = models.TextField(blank=True)
    patient = models.ForeignKey('accounts.PatientProfile', blank=True, null=True)
    doctor = models.ForeignKey('accounts.DoctorProfile', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.medicine