__author__ = 'Derek Popp'

from django import forms

from prescriptions.models import Prescription


class PrescriptionForm(forms.ModelForm):
    dosage = forms.DecimalField(min_value=0, max_digits=5, decimal_places=2,
                                error_messages={'required': 'Please enter a dosage amount.'})
    units = forms.CharField(max_length=5, error_messages={'required': 'Please enter a unit for the dosage.'})
    medicine = forms.CharField(label="Medication",
                               error_messages={'required': 'Please enter a name for the prescription.'})
    notes = forms.TextInput()

    class Meta:
        model = Prescription
        fields = ('medicine', 'dosage', 'units', 'notes')