from decimal import Decimal as D

from django.test import TestCase

from prescriptions.forms import PrescriptionForm
from prescriptions.models import Prescription


class PrescriptionFormTestCase(TestCase):

    def test_prescriptionform_valid(self):
        test_data = {
            'dosage': D('50'),
            'units': 'mg',
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertTrue(prescription_form.is_valid())
        prescription = Prescription(**prescription_form.cleaned_data)

        for key, value in test_data.items():
            self.assertEqual(getattr(prescription, key), value)

    def test_prescriptionform_invalid_negativedosage(self):
        test_data = {
            'dosage': D('-50.0'),
            'units': 'mg',
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertFalse(prescription_form.is_valid())

    def test_prescriptionform_invalid_highdosage(self):
        test_data = {
            'dosage': D('5345.67'),
            'units': 'mg',
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertFalse(prescription_form.is_valid())

    def test_prescriptionform_invalid_unitlength(self):
        test_data = {
            'dosage': D('50.0'),
            'units': 'mgndsfnfdn',
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertFalse(prescription_form.is_valid())

    def test_prescriptionform_invalid_nounit(self):
        test_data = {
            'dosage': D('50.0'),
            'units': None,
            'medicine': 'Friendship',
            'notes': 'Take sparingly',
            'patient': None,
            'doctor': None
        }
        prescription_form = PrescriptionForm(test_data)
        self.assertFalse(prescription_form.is_valid())

