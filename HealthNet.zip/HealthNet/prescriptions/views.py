__author__ = 'Derek Popp'

from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, Http404
from django.template import RequestContext
from django.shortcuts import render_to_response, get_object_or_404

from action_logging.models import log_action, get_content_type
from prescriptions.forms import PrescriptionForm
from prescriptions.models import Prescription
from prescriptions.utils import prescription_user_check


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def prescriptions(request, p_id):
    """adds a prescription to the patient's account"""
    context = RequestContext(request)

    postdata = request.POST.copy()

    # User Object
    p = User.objects.get(id=p_id).patientprofile
    #

    if request.method == 'POST':

        p_form = PrescriptionForm(data=request.POST)

        if p_form.is_valid():
            prescription = p_form.save(commit=False)
            prescription.patient = p
            prescription.doctor = request.user.doctorprofile
            prescription.save()

            log_action(user_id=request.user.id, content_type_id=get_content_type(app_name='prescriptions',
                                                                           model_name='prescription').id,
                       object_id=p.id, object_desc='patient \'%s\' has been assigned prescription \'%s\' by \'%s\''
                                                        % (p, prescription, request.user.doctorprofile),
                       action_flag=1)

            return HttpResponseRedirect(reverse('staff_change_user', args=[p_id]))

    else:
        p_form = PrescriptionForm()

    return render_to_response('staff_pages/doc_prescriptions.html', {'prescription_form': p_form,
                                                                     'patient': p}, context)


def delete_prescription(request, user_id, prescrip_id):
    """Removes a prescription from the system."""
    p = get_object_or_404(Prescription, pk=prescrip_id)

    if not prescription_user_check(request.user, p):
        raise Http404

    log_action(user_id=request.user.id, content_type_id=get_content_type(app_name='prescriptions',
                                                                         model_name='prescription').id,
               object_id=p.id, object_desc='\'%s\' has removed prescription \'%s\' from patient \'%s\''
                                                % (request.user.doctorprofile, p, p.patient),
               action_flag=3)
    p.delete()
    return HttpResponseRedirect(reverse('staff_change_user', args=[user_id]))