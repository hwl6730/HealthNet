import os
import datetime as dt

from django.core.urlresolvers import reverse
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import user_passes_test
from django.template import RequestContext

from action_logging.models import log_action, get_content_type
from stats.forms import DateForm
from HealthNet.settings import MEDIA_ROOT
from admin.forms import *
from prescriptions.models import Prescription
from hospitals.models import *


def handle_data(results, filename, start, end, type):
    DIR = MEDIA_ROOT + "stats/"

    if not os.path.isdir(DIR):
        os.makedirs(DIR)

    with open(DIR + filename, 'w') as info:
        info.write("Statistics for HealthNet " + type + ", " + str(start) + ", " + str(end) + "\n")
        for key, value in results.items():
            info.write(key + ", " + str(value) + "\n")
    info.close()

    response = HttpResponse(open(DIR + filename, 'rb').read(), content_type='application/txt')
    response['Content-Disposition'] = 'attachment; filename="' + filename
    return response


def patients(start, end, type):
    num_patients = num_male = num_female = ages = 0
    p_list = PatientProfile.objects.all()
    if p_list.count() == 0:
        return HttpResponseRedirect(reverse('admin_home'))
    for person in p_list:
        if start <= person.user.date_joined <= end:
            num_patients += 1
            if person.user.userprofile.gender == "M":
                num_male += 1
            else:
                num_female += 1
            ages += (dt.datetime.now().date().year - person.user.userprofile.date_of_birth.year)

    try:
        aa = ages / num_patients
    except ZeroDivisionError:
        aa = 0

    try:
        pm = float(num_male) / num_patients * 100.0
    except ZeroDivisionError:
        pm = 0

    try:
        pf = float(num_female) / num_patients * 100.0
    except ZeroDivisionError:
        pf = 0

    results = {'Average Age': aa, 'Number of Males': num_male,
               'Percentage of Males': pm, 'Number of Females': num_female,
               'Percentage of Females': pf, 'Total Number of Patients': num_patients}

    return handle_data(results, "patient_stats.csv", start, end, type)


def admission(start, end, type):
    num_admit = num_dis = num_hos = 0
    a_list = Admission.objects.all()
    hosp_dic = {}
    results = {}

    for admit in a_list:
        if start <= admit.start <= end:
            num_admit += 1
            if admit.doctor.hospital not in hosp_dic.keys():
                num_hos += 1
                hosp_dic[admit.doctor.hospital] = 1
        if start <= admit.end <= end:
            num_dis += 1
        if admit.explanation not in results.keys():
            results[admit.explanation] = 0
        else:
            results[admit.explanation] += 1

    results["Number of Patients Admitted"] = num_admit
    results["Number of Patients Discharged"] = num_dis
    results["Number of Hospitals Utilized"] = num_hos

    return handle_data(results, "admission_stats.csv", start, end, type)


def prescription(start, end, type):
    num_scripts = num_patients = num_per = 0
    docs = len(DoctorProfile.objects.all())
    p_list = Prescription.objects.all()
    patients = {}
    results = {}
    if len(p_list) == 0:
        return HttpResponseRedirect(reverse('admin_home'))
    for script in p_list:
        if start <= script.created_at <= end:
            num_scripts += 1
            if script.patient not in patients.keys():
                patients[script.patient] = 1
                num_patients += 1
            if script.medicine not in results.keys():
                results[script.medicine] = script.dosage
            else:
                results[script.medicine] += script.dosage

    try:
        ap = float(num_scripts) / num_patients
    except ZeroDivisionError:
        ap = 0

    try:
        apd = float(num_scripts) / docs
    except ZeroDivisionError:
        apd = 0

    results["Total Number of Prescriptions"] = num_scripts
    results["Total Number of Patients with Prescriptions"] = num_patients
    results["Average Number of Prescriptions per Patient"] = ap
    results["Average Number of Prescriptions per Doctor"] = apd

    return handle_data(results, "prescriptions_stats.csv", start, end, type)


def hospital(start, end, type):
    num_hos = 0
    h_list = Hospital.objects.all()
    results = {}

    for hos in h_list:
        if hos.created_at <= end:
            num_hos += 1

    results["Number of Hospitals"] = num_hos

    return handle_data(results, "hospital_stats.csv", start, end, type)


@user_passes_test(lambda u: u.is_superuser, login_url='/home/')
@login_required(login_url='/login')
def get_stat(request, type):
    context = RequestContext(request)
    postdata = request.POST.copy()
    try:
        admin = request.user.adminprofile
    except AdminProfile.DoesNotExist:
        admin = None

    if request.method == 'POST':
        date_form = DateForm(request.POST)
        if date_form.is_valid():
            start = date_form.cleaned_data['start']
            end = date_form.cleaned_data['end']

            if type == "patients":
                log_action(user_id=request.user.id,
                           content_type_id=get_content_type(app_name='auth', model_name='user').id,
                           object_id=request.user.id,
                           object_desc='\'%s\' has exported the current system patient statistics.'
                                       % (admin if admin else request.user), action_flag=4)
                return patients(start, end, type)
            if type == "admission":
                if admin:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system admission statistics.'
                                           % admin, action_flag=4)
                else:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system admission statistics.'
                                           % request.user, action_flag=4)
                return admission(start, end, type)
            if type == "prescription":
                if admin:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system prescription statistics.'
                                           % admin, action_flag=4)
                else:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system prescription statistics.'
                                           % request.user, action_flag=4)
                return prescription(start, end, type)
            if type == "hospital":
                if admin:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system hospital statistics.'
                                           % admin, action_flag=4)
                else:
                    log_action(user_id=request.user.id,
                               content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=request.user.id,
                               object_desc='\'%s\' has exported the current system hospital statistics.'
                                           % request.user, action_flag=4)
                return hospital(start, end, type)

            return HttpResponseRedirect(reverse('admin_home'))

    else:
        date_form = DateForm()

    return render_to_response('stats/date_select.html', {'a_info': date_form}, context)
