__author__ = 'Allen Sanford'

from django.conf.urls import patterns, url

from stats import views


urlpatterns = patterns('',
      url(r'^(\w+)', views.get_stat, name='admin_home'),
)