__author__ = 'Allen Sanford'

from django import forms

class DateForm(forms.Form):
    start = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", '%Y-%m-%d %H:%M:%S'],
                                error_messages={'required': 'Please enter a starting date.'})
    end = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S'],
                              error_messages={'required': 'Please enter an ending date.'})

    def is_valid(self, appt_id=None):
        valid = super(DateForm, self).is_valid()

        if not valid:
            return valid

        # check for pesky time-travelers
        if self.cleaned_data['end'] < self.cleaned_data['start']:
            self._errors['time_travel'] = self.error_class(['End date cannot be before the start date.'])
            return False

        return True