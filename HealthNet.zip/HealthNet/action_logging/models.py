from django.contrib.admin.models import LogEntry
from django.contrib.contenttypes.models import ContentType

# Create your models here.


def log_action(user_id, content_type_id, object_id, object_desc, action_flag, change_message=''):
    LogEntry.objects.log_action(user_id=user_id, object_id=object_id, action_flag=action_flag,
                               content_type_id=content_type_id, object_repr=object_desc, change_message=change_message)


def get_content_type(app_name='', model_name=''):
    content = ContentType.objects.get(app_label=app_name, model=model_name)
    return content
