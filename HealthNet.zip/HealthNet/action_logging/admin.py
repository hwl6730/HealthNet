from __future__ import unicode_literals
from django.contrib import admin
from django.utils.html import escape
from django.core.urlresolvers import reverse
from django.contrib.admin.models import LogEntry, DELETION
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import User

# Register your models here.

action_flag_dic = {
    1: 'ADDITION',
    2: 'CHANGE',
    3: 'DELETION',
    4: 'SYSTEM',
}


class LogEntryAdmin(admin.ModelAdmin):
    date_hierarchy = 'action_time'

    # noinspection PyProtectedMember
    readonly_fields = LogEntry._meta.get_all_field_names()

    list_filter = [
        'user',
        'content_type',
        'action_flag'
    ]

    search_fields = [
        'object_repr',
        'change_message'
    ]

    list_display = [
        'action_time',
        'user',
        'content_type',
        'object_link',
        'af_process',
        'change_message',
    ]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser and request.method != 'POST'

    def has_delete_permission(self, request, obj=None):
        return False

    def object_link(self, obj):
        if obj.action_flag == DELETION:
            link = escape(obj.object_repr)
        else:
            ct = obj.content_type
            link = '<a href="%s">%s</a>' % (
                reverse('admin:%s_%s_change' % (ct.app_label, ct.model), args=[obj.object_id]),
                escape(obj.object_repr),
            )
        return link
    object_link.allow_tags = True
    object_link.admin_order_field = 'object_repr'
    object_link.short_description = 'object'

    def queryset(self, request):
        return super(LogEntryAdmin, self).queryset(request) \
            .prefetch_related('content_type')

    # noinspection PyMethodMayBeStatic
    def af_process(self, obj):
        return action_flag_dic[obj.action_flag]

    af_process.short_description = 'Action flag'

admin.site.register(LogEntry, LogEntryAdmin)


def test1():
    u = User.objects.get(id=2)
    LogEntry.objects.log_action(user_id=u.id, object_id=u.id, action_flag=1,
                               content_type_id=ContentType.objects.get_for_model(User).pk,
                               object_repr='This is an object')