from django.test import TestCase
from django.contrib.auth.models import User

from action_logging.models import log_action, get_content_type, LogEntry


class LoggingTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username='u1', password='pass')

    def test_Log_exists(self):
        log_action(user_id=self.u1.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                   object_id=self.u1.id, object_desc='User \'%s\' has logged in.' % self.u1.username, action_flag=4)
        self.assertIn(LogEntry.objects.get(user_id=self.u1.id), LogEntry.objects.all())