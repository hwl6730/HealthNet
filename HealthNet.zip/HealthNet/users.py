__author__ = 'Derek Popp'
from datetime import datetime

from django.contrib.auth.models import Group
from django.utils.timezone import now

from accounts.models import *
from hospitals.models import Hospital
from messages.models import Message


doctors_group = Group.objects.get_or_create(name='Doctors')
nurse_group = Group.objects.get_or_create(name='Nurses')
patients_group = Group.objects.get_or_create(name='Patients')

u1 = User.objects.create_user(username='p1', password='x', first_name="Wade", last_name="Wilson")
u2 = User.objects.create_user(username='p2', password='x', first_name="Steve", last_name="Rogers")
patients_group[0].user_set.add(u1)
patients_group[0].user_set.add(u2)
d1 = User.objects.create_user(username='d1', password='x', first_name="Stephen", last_name="Strange")
doctors_group[0].user_set.add(d1)
n1 = User.objects.create_user(username='n1', password='x', first_name="Carol", last_name="Danvers")
nurse_group[0].user_set.add(n1)

up1 = UserProfile.objects.create(user=u1, address="123 Somewhere Street", date_of_birth=datetime(1995, 1, 1),
                                 phone_number="1234567890", city="Nowhere Town", state="Texas", zipcode='12345',
                                 country="USA", gender='M')
up4 = UserProfile.objects.create(user=u2, address="123 Somewhere or Other", date_of_birth=datetime(1918, 6, 4),
                                 phone_number="1234567890", city="Nowhere Town", state="New York", zipcode='12345',
                                 country="USA", gender='M')
up2 = UserProfile.objects.create(user=d1, address="456 Somewhere Street", date_of_birth=now(),
                                 phone_number="1234567890", city="Nowhere Town", state="Texas", zipcode='12345',
                                 country="USA", gender='M')
up3 = UserProfile.objects.create(user=n1, address="789 Somewhere Street", date_of_birth=now(),
                                 phone_number="1234567890", city="Nowhere Town", state="Texas", zipcode='12345',
                                 country="USA", gender='F')
hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                              state='Texas', zipcode='12345', country="USA")
hos2 = Hospital.objects.create(name='All-American Hospital', address='999 Somewhere Street', city='Nowhere Town',
                              state='Texas', zipcode='12345', country="USA")

dp1 = DoctorProfile.objects.create(user=d1, hospital=hos)
np1 = NurseProfile.objects.create(user=n1)
np1.hospital.add(hos)
pp1 = PatientProfile.objects.create(user=u1, doctor=dp1, hospital=hos, health_insurance="advkjsdfj",
                                    ice_name="Mom", ice_phone="55555555555")
pp2 = PatientProfile.objects.create(user=u2, doctor=dp1, hospital=hos2, health_insurance="Army",
                                    ice_name="Bucky", ice_phone="7777777777")

mess = Message.objects.create(subject="Cut out the shenanigans. I won't be as easy on you.",
                              content="I mean it Wade. Don't make me come over to you. - Doctor Strange",
                              sender=up2, recipient=up1)

mess2 = Message.objects.create(subject="I told you to stop.",
                               content="I don't need the Eye of Agamatto to see you are an imbecile. - Doctor Strange",
                               sender=up2, recipient=up1)
mess3 = Message.objects.create(subject="Last Warning",
                               content="Quit it. - Doctor Strange",
                               sender=up2, recipient=up1)
mess4 = Message.objects.create(subject="That's it.",
                               content="I'm on my way. - Doctor Strange",
                               sender=up2, recipient=up1)