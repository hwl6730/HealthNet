import time
import os
import shutil
import zipfile

from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, Http404
from django.template import RequestContext
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse

from action_logging.models import log_action, get_content_type
from documents.forms import DocumentForm
from documents.models import Document
from HealthNet.settings import MEDIA_ROOT
from documents.utils import document_user_check


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def upload(request, p_id):
    """Uploads a document to a patient's file"""
    context = RequestContext(request)

    postdata = request.POST.copy()

    # User Object
    p = User.objects.get(id=p_id).patientprofile
    #

    if request.method == 'POST':
        u_form = DocumentForm(request.POST, request.FILES)
        if u_form.is_valid():
            doc = u_form.save(commit=False)
            p.document_set.add(doc)
            doc.save()
            log_action(user_id=request.user.id,
                       content_type_id=get_content_type(app_name='documents', model_name='document').id,
                       object_id=doc.patient.id,
                       object_desc='\'%s\' has uploaded file \'%s\' to the profile of \'%s\''
                                   % (request.user.doctorprofile, doc, doc.patient), action_flag=1)

            return HttpResponseRedirect(reverse('staff_change_user', args=[p_id]))

    else:
        u_form = DocumentForm

    return render(request, 'staff_pages/doc_uploads.html',
                  {'u_form': u_form, 'doctor': request.user, 'user': request.user, 'patient': p})


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def delete_doc(request, user_id, doc_id):
    doc = get_object_or_404(Document, pk=doc_id)

    if not document_user_check(request.user, doc):
        raise Http404

    log_action(user_id=request.user.id,
               content_type_id=get_content_type(app_name='documents', model_name='document').id,
               object_id=doc.patient.id,
               object_desc='\'%s\' has deleted file \'%s\' from the profile of \'%s\''
                           % (request.user.doctorprofile, doc, doc.patient), action_flag=3)
    doc.delete()
    return HttpResponseRedirect(reverse('staff_change_user', args=[user_id]))


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def release_doc(request, user_id, doc_id):
    document = Document.objects.get(id=doc_id)
    document.released = True
    document.save()
    log_action(user_id=request.user.id,
               content_type_id=get_content_type(app_name='documents', model_name='document').id,
               object_id=document.patient.id,
               object_desc='\'%s\' has released file \'%s\' to patient \'%s\''
                           % (request.user.doctorprofile, document, document.patient), action_flag=2)
    return HttpResponseRedirect(reverse('staff_change_user', args=[user_id]))


def write_info(file, patient):
    file.write("Export Date: " + time.strftime("%d/%m/%Y") + "\n")
    file.write("Patient: " + str(patient) + "\n")
    file.write("Doctor: " + str(patient.doctor) + "\n")
    file.write("Hospital: " + str(patient.hospital) + "\n")
    file.write("Health Insurance: " + str(patient.health_insurance) + "\n")
    file.write("Emergency Contact: " + str(patient.ice_name) + "\n")
    file.write("Emergency Contact Phone Number: " + str(patient.ice_phone) + "\n")


@user_passes_test(lambda u: u.groups.filter(name='Patients').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def export(request, user_id):
    user = User.objects.get(id=user_id)
    patient = user.patientprofile

    P_DIR = MEDIA_ROOT + "user%s/" % user_id

    release_files = []
    released = {}
    for doc in patient.document_set.all():
        if doc.released:
            released[str(doc.docfile)[6:]] = doc.comments

    if not os.path.isdir(P_DIR):
        os.makedirs(P_DIR)

    for file in os.listdir(P_DIR):
        if file in released:
            release_files.append("/" + file)

    with open(P_DIR + "/Medical_Information.txt", 'w') as basic_info:
        write_info(basic_info, patient)
    basic_info.close()

    release_files.append("/Medical_Information.txt")

    if os.path.isdir(P_DIR + "/export"):
        shutil.rmtree(P_DIR + '/export')
    os.makedirs(P_DIR + "/export")

    for file in release_files:
        shutil.copyfile(P_DIR + file, P_DIR + "/export" + file)

    files = P_DIR + "/export"
    zf = zipfile.ZipFile("%s.zip" % files, "w", zipfile.ZIP_DEFLATED)
    abs_src = os.path.abspath(files)
    for dirname, subdirs, files in os.walk(files):
        for filename in files:
            absname = os.path.abspath(os.path.join(dirname, filename))
            arcname = absname[len(abs_src) + 1:]
            zf.write(absname, arcname)
    zf.close()

    response = HttpResponse(open(P_DIR + "/export.zip", 'rb').read(), content_type='application/zip')
    response['Content-Disposition'] = 'attachment; filename="export.zip"'
    log_action(user_id=request.user.id,
               content_type_id=get_content_type(app_name='documents', model_name='document').id,
               object_id=request.user.id,
               object_desc='Patient \'%s\' has exported their released medical information.'
                           % patient, action_flag=3)
    return response