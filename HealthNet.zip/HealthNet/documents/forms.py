from django import forms

from documents.models import Document


class DocumentForm(forms.ModelForm):
    docfile = forms.FileField(
        help_text='Maximum Upload size of 42 megabytes',
        required=True,
        error_messages={'required': 'Please select a file to upload.'}
    )

    name = forms.CharField(required=True, label="File Name",
                           error_messages={'required': 'Please enter a filename.'})

    comments = forms.TextInput

    class Meta:
        model = Document
        fields = ('docfile', 'name', 'comments')

