import os

from django.db import models


def get_name(instance, filename):
    return os.path.join(
        "user%d" % instance.patient.user.id, filename
    )


class Document(models.Model):
    """Model for uploading and storing a document"""

    name = models.CharField(blank=False, max_length=50)
    comments = models.TextField(blank=True)
    patient = models.ForeignKey('accounts.PatientProfile', blank=True, null=True)

    released = models.BooleanField(default=False)
    docfile = models.FileField(blank=False, upload_to=get_name)

    def __str__(self):
        return self.name