__author__ = 'Derek'
from accounts.models import DoctorProfile


def document_user_check(user, doc):
    try:
        doctor = user.doctorprofile
    except DoctorProfile.DoesNotExist:
        return False

    return doctor == doc.patient.doctor