from io import StringIO

from django.test import TestCase
from django.core.files.uploadedfile import SimpleUploadedFile

from documents.forms import DocumentForm
from documents.models import Document


class DocumentTestCase(TestCase):  # We won't use external files for testing, defeats the purpose of unit tests

    def setUp(self):  # create the spoof file
        self.imgfile = StringIO('GIF87a\x01\x00\x01\x00\x80\x01\x00\x00\x00\x00ccc,\x00'
                                '\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;')
        self.imgfile.name = 'test_img_file.gif'
        self.file = SimpleUploadedFile(self.imgfile.name, bytes(self.imgfile.read(), 'utf-8'), content_type='image/gif')

    def test_DocumentForm_valid(self):
        test_data = {'name': self.imgfile.name,
                     'comments': 'This is a file.'}
        file_data = {'docfile': self.file}
        doc_form = DocumentForm(test_data, file_data)
        self.assertTrue(doc_form.is_valid())
        upload = Document(**doc_form.cleaned_data)
        for key, value in test_data.items() and file_data.items():
            self.assertEqual(getattr(upload, key), value)

    def test_DocumentForm_invalid_nofile(self):
        test_data = {'name': self.imgfile.name,
                     'comments': 'This is a file.'}
        file_data = {'docfile': None}
        doc_form = DocumentForm(test_data, file_data)
        self.assertFalse(doc_form.is_valid())

    def test_DocumentForm_invalid_noname(self):
        test_data = {'name': None,
                     'comments': 'This is a file.'}
        file_data = {'docfile': self.file}
        doc_form = DocumentForm(test_data, file_data)
        self.assertFalse(doc_form.is_valid())

    def test_DocumentForm_valid_nocomment(self):
        test_data = {'name': self.imgfile.name,
                     'comments': ''}
        file_data = {'docfile': self.file}
        doc_form = DocumentForm(test_data, file_data)
        self.assertTrue(doc_form.is_valid())
        upload = Document(**doc_form.cleaned_data)
        for key, value in test_data.items() and file_data.items():
            self.assertEqual(getattr(upload, key), value)

    def tearDown(self):
        del self.imgfile.name, self.imgfile, self.file