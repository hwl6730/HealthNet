from django.contrib import admin

from hospitals.models import *
from accounts.models import Transfer

admin.site.register(Admission)
admin.site.register(Transfer)