from datetime import datetime

from django.test import TestCase
from django.utils.timezone import get_current_timezone
from django.contrib.auth.models import User

from hospitals.models import *
from accounts.models import *
from hospitals.forms import AdmissionForm, TransferForm


class AdmissionTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username='p1', password='x', first_name="Wade", last_name="Wilson")
        self.d1 = User.objects.create_user(username='d1', password='x', first_name="Stephen", last_name="Strange")
        self.dp1 = DoctorProfile.objects.create(user=self.d1)
        self.pp1 = PatientProfile.objects.create(user=self.u1, doctor=self.dp1, health_insurance="advkjsdfj",
                                                 ice_name="Mom", ice_phone="5555555555")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_AdmissionForm_valid(self):
        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id,
                     'explanation': 'CC',
                     'hospital': self.hos.id}
        add_form = AdmissionForm(test_data)
        self.assertTrue(add_form.is_valid())
        tz = get_current_timezone()
        test_data['start'] = datetime.strptime(test_data['start'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        test_data['end'] = datetime.strptime(test_data['end'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz)
        addm = Admission(**add_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'patient':
                self.assertEqual(getattr(addm, key), self.pp1)
            elif key == 'doctor':
                self.assertEqual(getattr(addm, key), self.dp1)
            elif key == 'hospital':
                self.assertEqual(getattr(addm, key), self.hos)
            else:
                self.assertEqual(getattr(addm, key), value)

    def test_AdmissionForm_invalid_noreason(self):
        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id,
                     'explanation': None,
                     'hospital': self.hos.id}
        add_form = AdmissionForm(test_data)
        self.assertFalse(add_form.is_valid())

    def test_AdmissionForm_invalid_invalidreason(self):
        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 12:00:00',
                     'end': '2099-04-23 13:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id,
                     'explanation': 'XX',
                     'hospital': self.hos.id}
        add_form = AdmissionForm(test_data)
        self.assertFalse(add_form.is_valid())

    def test_AdmissionForm_invalid_timetravel(self):
        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 13:00:00',
                     'end': '2099-04-23 12:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id,
                     'explanation': 'XX',
                     'hospital': self.hos.id}
        add_form = AdmissionForm(test_data)
        self.assertFalse(add_form.is_valid())

    def test_AdmissionForm_invalid_nohospital(self):
        test_data = {'title': 'Test Admission',
                     'start': '2099-04-23 13:00:00',
                     'end': '2099-04-23 12:00:00',
                     'patient': self.pp1.id,
                     'doctor': self.dp1.id,
                     'explanation': 'XX',
                     'hospital': None}
        add_form = AdmissionForm(test_data)
        self.assertFalse(add_form.is_valid())

    def tearDown(self):
        del self.u1, self.d1, self.dp1, self.pp1, self.hos


class TransferTestCase(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user(username='p1', password='x', first_name="Wade", last_name="Wilson")
        self.pp1 = PatientProfile.objects.create(user=self.u1, doctor=None, health_insurance="advkjsdfj",
                                                 ice_name="Mom", ice_phone="5555555555")
        self.hos = Hospital.objects.create(name='Strong Memorial', address='999 Somewhere Street', city='Nowhere Town',
                                           state='Texas', zipcode='12345', country="USA")

    def test_TransferForm_valid(self):
        test_data = {'patient': self.pp1.id,
                     'newHospital': self.hos.id}
        t_form = TransferForm(test_data)
        self.assertTrue(t_form.is_valid())
        transfer = Transfer(**t_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'patient':
                self.assertEqual(getattr(transfer, key), self.pp1)
            elif key == 'newHospital':
                self.assertEqual(getattr(transfer, key), self.hos)
            else:
                self.assertEqual(getattr(transfer, key), value)

    def test_TransferForm_invalid_nohos(self):
        test_data = {'patient': self.pp1.id,
                     'newHospital': None}
        t_form = TransferForm(test_data)
        self.assertFalse(t_form.is_valid())

    def test_TransferForm_invalid_nopatient(self):
        test_data = {'patient': None,
                     'newHospital': self.hos.id}
        t_form = TransferForm(test_data)
        self.assertFalse(t_form.is_valid())

    def test_TransferForm_invalid_nofields(self):
        test_data = {'patient': None,
                     'newHospital': None}
        t_form = TransferForm(test_data)
        self.assertFalse(t_form.is_valid())

    def tearDown(self):
        del self.u1, self.hos, self.pp1