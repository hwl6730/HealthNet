from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponseRedirect

from action_logging.models import log_action, get_content_type
from accounts import views as account_views
from hospitals.forms import *


@user_passes_test(lambda u: u.groups.filter(name='Nurses').exists() or u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def admit_patient(request, p_id):
    patient = User.objects.get(id=p_id)
    user = request.user

    if request.method == 'POST':
        a_form = AdmissionForm(request.POST)

        if a_form.is_valid():

            admission = a_form.save(commit=False)
            patient.patientprofile.admitted = True
            patient.patientprofile.save()
            admission.save()

            log_action(user_id=user.id,
                       content_type_id=get_content_type(app_name='hospitals', model_name='hospital').id,
                       object_id=patient.id, object_desc='Patient \'%s\' has been admitted into hospital \'%s\''
                                                         % (patient.patientprofile, patient.patientprofile.hospital),
                       action_flag=1)
            return redirect(account_views.change_info_staff, p_id=p_id)
    else:
        a_form = AdmissionForm(initial={'patient': patient.patientprofile,
                                        'doctor': patient.patientprofile.doctor,
                                        'hospital': patient.patientprofile.hospital}, )

    if user.groups.filter(name='Doctors').exists():
        doc_bool = True
    else:
        doc_bool = False

    return render(request, 'hospital/admission.html',
                  {'patient': patient, 'user': request.user, 'doctor': request.user, 'nurse': request.user,
                   'doc_bool': doc_bool, 'a_info': a_form})


@user_passes_test(lambda u: u.groups.filter(name='Doctors').exists()
    , login_url='/home/')
@login_required(login_url='/login')
def discharge_patient(request, p_id):
    # User Object
    patient = User.objects.get(id=p_id)

    patient.patientprofile.admitted = False
    patient.patientprofile.save()
    return redirect(account_views.change_info_staff, p_id=p_id)



@user_passes_test(lambda u: (u.groups.filter(name='Doctors').exists() or u.is_superuser))
def transfer_patient(request, p_id):
    patient = User.objects.get(id=p_id).patientprofile
    doc_bool = False
    if request.user.groups.filter(name='Doctors').exists():
        doc_bool = True
    #if the user is a doctor, transfers the patient to the user's hospital without any confirmation 
    if doc_bool:
        patient.hospital=request.user.doctorprofile.hospital
        patient.save()
        log_action(user_id=request.user.id,
                   content_type_id=get_content_type(app_name='hospitals', model_name='hospital').id,
                   object_id=patient.id, object_desc='User \'%s\' has been transferred into hospital \'%s\''
                                                     % (patient.user.username, patient.hospital), action_flag=2)
        return HttpResponseRedirect('/staff/patients/')

    if request.method == 'POST':
        t_form = TransferForm(data=request.POST)
        doc_bool = False

        if t_form.is_valid():
            h = t_form.cleaned_data['newHospital']
            patient.hospital = h
            patient.save()

            doc_bool = False
            if request.user.groups.filter(name='Doctors').exists():
                doc_bool = True
            log_action(user_id=request.user.id,
                       content_type_id=get_content_type(app_name='hospitals', model_name='hospital').id,
                       object_id=patient.id, object_desc='User \'%s\' has been transferred into hospital \'%s\''
                                                         % (patient.user.username, patient.hospital), action_flag=2)
            return HttpResponseRedirect('/home')
    else:
        t_form = TransferForm(initial={'patient': patient}, )

    if request.user.is_superuser:
        return render(request, 'admin/admin_transfer.html',
                      {'patient': patient, 'user': request.user, 'doctor': request.user, 'nurse': request.user,
                       'doc_bool': doc_bool, 't_info': t_form})
    #return render(request, 'hospital/transfer.html',
    #              {'patient': patient, 'user': request.user, 'doctor': request.user, 'nurse': request.user,
    #               'doc_bool': doc_bool, 't_info': t_form})
























