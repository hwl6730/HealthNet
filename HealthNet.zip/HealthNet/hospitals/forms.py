from hospitals.models import *
from accounts.models import *

REASON_CHOICES = (
    ('HD', 'Heart Disease'), ('BB', 'Broken Bone'),
    ('CC', 'Cancer'), ('ID', 'Infectious Disease')
)


class AdmissionForm(forms.ModelForm):
    """Form to complete when admitting a patient"""

    title = forms.CharField(error_messages={'required': 'Please enter a title.'})
    explanation = forms.ChoiceField(widget=forms.Select, choices=REASON_CHOICES,
                                    error_messages={'required': "Please select a Reason for Admission."})
    doctor = forms.ModelChoiceField(queryset=DoctorProfile.objects.all(),
                                    error_messages={'required': 'Please select a doctor.'})
    patient = forms.ModelChoiceField(queryset=PatientProfile.objects.all(),
                                     error_messages={'required': 'Please select a patient.'})
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all(),
                                     error_messages={'required': 'Please select a hospital.'})
    start = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", '%Y-%m-%d %H:%M:%S'],
                                error_messages={'required': 'Please enter a starting date/time.'})
    end = forms.DateTimeField(input_formats=["%Y-%m-%dT%H:%M:%SZ", '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S'],
                              error_messages={'required': 'Please enter an ending date/time.'})

    def is_valid(self):

        # run parent validation first
        valid = super(AdmissionForm, self).is_valid()

        # if not valid, return
        if not valid:
            return valid

        # check for pesky time-travelers
        if self.cleaned_data['end'] < self.cleaned_data['start']:
            self._errors['time_travel'] = self.error_class(['End date cannot be before the start date.'])
            return False

        return True

    class Meta:
        model = Admission
        fields = {'title', 'explanation', 'start', 'end', 'doctor', 'patient', 'hospital'}


class TransferForm(forms.ModelForm):
    newHospital = forms.ModelChoiceField(Hospital.objects.all(), label="Transfer to:", required=True,
        error_messages={'required': 'Please select a hospital to transfer to.'})

    class Meta:
        model = Transfer
        fields = {'newHospital', 'patient'}