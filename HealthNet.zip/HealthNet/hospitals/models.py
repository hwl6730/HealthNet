from django.db import models


class Hospital(models.Model):
    name = models.CharField(max_length=200)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    zipcode = models.CharField(max_length=33)
    country = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Admission(models.Model):
    title = models.CharField(max_length=200)
    start = models.DateTimeField()
    end = models.DateTimeField()
    doctor = models.ForeignKey('accounts.DoctorProfile')
    patient = models.ForeignKey('accounts.PatientProfile')
    explanation = models.TextField()
    hospital = models.ForeignKey('Hospital')

