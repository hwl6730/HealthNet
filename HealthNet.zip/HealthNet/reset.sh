#!/bin/bash
rm healthNet.db
python3 manage.py sql login
python3 manage.py syncdb
python3 manage.py shell < users.py
python3 manage.py runserver
