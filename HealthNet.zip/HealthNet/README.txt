1)Installation:
	Unzip the HealthNet folder into directory of choice.
	Open the HealthNet folder to the main directory.
	Run the resetDB batch file.
	Type yes to create a new user.
	Then follow the instructions to create a superuser.
	Hit enter and the server will now be running on localhost port 8000.
	*Note: To run HealthNet off a different port, close the command window.
	*Open up a command window and navigate inside the HealthNet folder.
	*Type in python manage.py runserver [port_of_choice]
	Open up a web browser and type in localhost:[port_of_choice] (or 127.0.0.1:[port_of_choice])
	You are now at HealthNet's main page.
	Target Environment: This has been designed to work on Windows 7 machines with Python 3.2.2,
	Django 1.6.5, HTML 5, CSS 3, SQLite 3.3, Internet Browser, javascript must be enabled, and a valid internet connection.

2)Known bugs and disclaimers
	The admin creation form errors display, but the messages are not helpful. The error messages need to be customized.
	Chrome specific: When a PDF is uploaded to a patient's documents, it must be downloaded by right-clicking and selecting the "save as" option.

3) Known missing Release-2 features.
	System log statistics, patient information exporting, and test releasing.
	Hospital transfers cannot be completed.

4) Admin Account Usage

	-Creating Users/Hospitals
		Login as an admin account
		Either choose which you would like to create from the homepage or the create button at the top
		Fill in the required fields and submit
		
	-Viewing groups
		Login as an admin account
		Choose "Groups" at the top of the homepage
		Select the group you wish to view
		
	-Viewing Activity Log
		Login as an admin account
		The homepage displays all recent activity in the system
		
	-Transfering a Patient
		Login as an admin account
		Choose "Groups" at the top of the homepage
		Choose the "Patients" group
		Click the "Transfer" button next to the patient you wish to transfer
		Click "Submit"
		
5) Patient Account Usage

	-Registering a Patient Account
		From the HealthNet homepage, choose register at the top
		Supply all required information and submit
		The system will automatically log you into the system
		
	-Viewing/Editing Personal Information
		Click the "Welcome" option from the top bar and choose Personal Information
		You are now viewing all the account's personal information
		To edit the information, change any of the fields an click submit
		If you do not wish for your changes to be saved, clicking reset will reset all information
		
	-Viewing Medical Information
		Either choose medical information under the "Welcome" option at the top
		or choose the "Medical Info" option
		
	-Managing Appointments
		Select "Manage Appointments" from the top bar
		To create a new appointment, click the "Create Appointment" button,
		supply the appropriate information and submit
		To delete a appointment, click the red "X" next to the appointment you 
		wish to delete
		
	-Messaging
		Select "Messages" from the top menu, and choose "Go to inbox"
		To create a new message, click "Compose", fill in the information and send
		
		To reply to a message, choose the message you wish to reply to,
		click the arrow above the message and send
		
		To archive messages you were sent click the middle button above the message
		
		To delete a message, click the right button above the message
	
6) Nurse Account Usage

	-Viewing/Editing Personal Information
		Click the "Welcome" option from the top bar and choose Personal Information
		You are now viewing all the account's personal information
		To edit the information, change any of the fields an click submit
		If you do not wish for your changes to be saved, clicking reset will reset all information
		
	-Viewing/Editing Patient Information
		Select the "Patient Information" option from the top bar or under the 
		"Welcome" option
		Select which patient's information you would like to view/edit
		You are now viewing the patient's medical information
		To edit, simply make changes to the fields and click submit

	-Viewing Appointments
		Select "Manage Appointments" from the top bar
		To view an appoint, click on the desired appointment
	
	-Messaging
		Select "Messages" from the top menu, and choose "Go to inbox"
		To create a new message, click "Compose", fill in the information and send
		
		To reply to a message, choose the message you wish to reply to,
		click the arrow above the message and send
		
		To archive messages you were sent click the middle button above the message
		
		To delete a message, click the right button above the message
	
7) Doctor Account Usage

	-Viewing/Editing Personal Information
		Click the "Welcome" option from the top bar and choose Personal Information
		You are now viewing all the account's personal information
		To edit the information, change any of the fields an click submit
		If you do not wish for your changes to be saved, clicking reset will reset all information

	-Viewing/Editing Patient Information
		Select the "Patient Information" option from the top bar or under the 
		"Welcome" option
		Select which patient's information you would like to view/edit
		You are now viewing the patient's medical information
		To edit, simply make changes to the fields and click submit
		
	-Adding/Removing Prescriptions
		Select the "Patient Information" option from the top bar or under the 
		"Welcome" option
		To add, click the "Add Prescription" button, enter the appropriate 
		information, and submit
		To delete, click the red "X" next to the prescription you wish to remove
		
	-Test upload
		Select the "Patient Information" option from the top bar or under the 
		"Welcome" option
		Click the "Upload Document" button
		Select "Choose File", find the file you wish to upload, and click "Upload"
		
	-Managing Appointments
		Select "Manage Appointments" from the top bar
		To create a new appointment, click the "Create Appointment" button,
		supply the appropriate information and submit
		To delete a appointment, click the red "X" next to the appointment you 
		wish to delete
		
	-Messaging
		Select "Messages" from the top menu, and choose "Go to inbox"
		To create a new message, click "Compose", fill in the information and send
		
		To reply to a message, choose the message you wish to reply to,
		click the arrow above the message and send
		
		To archive messages you were sent click the middle button above the message
		
		To delete a message, click the right button above the message
		
	-Transfering a Patient
		Login as a doctor account
		Click "Patient Info" from the top bar
		Click the "Transfer" button next to the patient you wish to transfer
		Click submit
		
8) Developer Contact Information

	Name: Harry Longwell
	Role: Requirements Coordinator
	Email: hwl6730@rit.edu
	Phone: (607) 857-7438
	
	Name: Derek Popp
	Role: Test Coordinator
	Email: dap1513@g.rit.edu
	Phone: 203-501-0877
	
	Name: Ross Kinsey
	Role: Configuration and QA Coordinator
	Email: rxk1497@g.rit.edu
	Phone: 571-230-7492
	
	Name: Roland (Allen) Sanford
	Role: Development Coordinator
	Email: ras9841@rit.edu
	Phone: 585-590-7489
	
	Name: Tyler Shank
	Role: Team Coordinator
	Email: trs5953@rit.edu
	Phone: 631-790-7916
9) Files in Release-2/cross-team-testing
    SWEN261_Requirements_TeamB_R2Beta.docx  
    TestCaseTracker_TeamB_R2Beta.xlsx
    README.txt
    TeamB_R2Beta.zip
