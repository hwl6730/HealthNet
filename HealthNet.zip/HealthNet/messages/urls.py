__author__ = 'Derek Popp'

from django.conf.urls import patterns, url

from messages.views import *


urlpatterns = patterns(
    '',
    url(r'^(?P<folder_name>\w+)$', switcher, name='to_folder'),
    url(r'^$', inbox, name='msg_redirect'),
    url(r'^inbox/(?P<mess_id>\d+)$', display_message, name='display_message'),
    url(r'^stt/(?P<mess_id>\d+)$', msg_to_trash, name='trash_message'),
    url(r'^sta/(?P<mess_id>\d+)$', msg_to_archive, name='archive_message'),



)