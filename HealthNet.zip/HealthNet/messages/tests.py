from datetime import date

from django.test import TestCase
from django.contrib.auth.models import User

from messages.models import Message
from messages.forms import MessageForm
from accounts.forms import UserProfileForm

# Create your tests here.


class MessagesTestCase(TestCase):
    def setUp(self):  # make a dummy user to unit test messages
        User.objects.create_user(username="test1", password="pass", first_name="John", last_name="Doe")
        acct = User.objects.get(username="test1")
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '14623',
                     'country': "USA"}
        user = UserProfileForm(test_data)
        self.assertTrue(user.is_valid())
        self.user1 = user.save(commit=False)
        self.user1.user = acct
        self.user1.save()
        for key, value in test_data.items():
            self.assertEqual(getattr(self.user1, key), value)

    def test_MessageForm_valid(self):  # valid message
        test_data = {'recipient': self.user1.id,
                     'subject': 'Test Subject',
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertTrue(msg_form.is_valid())
        msg = Message(**msg_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'recipient':
                self.assertEqual(getattr(msg, key), self.user1)
            else:
                self.assertEqual(getattr(msg, key), value)

    def test_MessageForm_valid_blanksubject(self):  # valid message, blank subject
        test_data = {'recipient': self.user1.id,
                     'subject': '',
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertTrue(msg_form.is_valid())
        msg = Message(**msg_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'recipient':
                self.assertEqual(getattr(msg, key), self.user1)
            else:
                self.assertEqual(getattr(msg, key), value)

    def test_MessageForm_valid_blankbody(self):  # valid message, blank body
        test_data = {'recipient': self.user1.id,
                     'subject': 'Test Subject',
                     'content': ''}
        msg_form = MessageForm(test_data)
        self.assertTrue(msg_form.is_valid())
        msg = Message(**msg_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'recipient':
                self.assertEqual(getattr(msg, key), self.user1)
            else:
                self.assertEqual(getattr(msg, key), value)

    def test_MessageForm_valid_blank(self):  # valid, blank message
        test_data = {'recipient': self.user1.id,
                     'subject': '',
                     'content': ''}
        msg_form = MessageForm(test_data)
        self.assertTrue(msg_form.is_valid())
        msg = Message(**msg_form.cleaned_data)
        for key, value in test_data.items():
            if key == 'recipient':
                self.assertEqual(getattr(msg, key), self.user1)
            else:
                self.assertEqual(getattr(msg, key), value)

    def test_MessageForm_invalid_norecipient(self):  # no recipient specified
        test_data = {'recipient': None,
                     'subject': 'Test Subject',
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertFalse(msg_form.is_valid())

    def test_MessageForm_invalid_invalidrecipient(self):  # user id doesn't exist
        test_data = {'recipient': 9999,  # user id 9999 really shouldn't exist in the test database at this point
                     'subject': 'Test Subject',
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertFalse(msg_form.is_valid())

    def test_MessageForm_invalid_subjecttoolong(self):  # subject > 120 characters
        test_data = {'recipient': self.user1.id,
                     'subject': 'x' * 125,
                     'content': 'This is a test message'}
        msg_form = MessageForm(test_data)
        self.assertFalse(msg_form.is_valid())