from django.shortcuts import render, HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.utils import timezone
from django.contrib.auth.decorators import login_required

from messages.forms import MessageForm
from messages.models import Message
from action_logging.models import *


@login_required(login_url='/login')
def folder(request, folder_msgs):
    user = request.user.userprofile

    if request.method == 'POST':

        message_form = MessageForm(data=request.POST)

        if message_form.is_valid():

            message = message_form.save(commit=False)
            message.sender = user
            message.recipient = message_form.cleaned_data['recipient']
            message.save()

            log_action(user_id=request.user.id, content_type_id=get_content_type(app_name='messages',
                    model_name='message').id, object_id=message.id, object_desc=
                    'User \'%s\' has sent a message to \'%s\'' % (request.user.username, message.recipient),
                    action_flag=1)

            return HttpResponseRedirect(reverse('to_folder', kwargs={'folder_name': 'inbox'}))

    else:
        message_form = MessageForm()

    if request.user.groups.filter(name='Patients').exists():
        return render(request, 'messaging/folder_display.html', {
            'patient': request.user, 'mess_form': message_form, 'display_msgs': folder_msgs
        })
    elif request.user.groups.filter(name='Doctors').exists():
        return render(request, 'messaging/staff/staff_folder_display.html', {
            'doctor': request.user, 'mess_form': message_form, 'display_msgs': folder_msgs, 'doc_bool': True
        })
    elif request.user.groups.filter(name='Nurses').exists():
        return render(request, 'messaging/staff/staff_folder_display.html', {
            'nurse': request.user, 'mess_form': message_form, 'display_msgs': folder_msgs, 'doc_bool': False
        })
    elif request.user.is_superuser:
        return render(request, 'messaging/admin/admin_folder_display.html', {
            'user': request.user, 'mess_form': message_form, 'display_msgs': folder_msgs
        })


@login_required(login_url='/login')
def switcher(request, folder_name):
    if folder_name == 'inbox':
        return folder(request, request.user.userprofile.get_inbox())
    elif folder_name == 'sent':
        return folder(request, request.user.userprofile.get_sent())
    elif folder_name == 'archived':
        return folder(request, request.user.userprofile.get_archived())
    elif folder_name == 'trash':
        return folder(request, request.user.userprofile.get_trash())
    else:
        return folder(request, request.user.userprofile.get_inbox())


@login_required(login_url='/login')
def inbox(request):
    return folder(request, request.user.userprofile.get_inbox())


@login_required(login_url='/login')
def display_message(request, mess_id):
    user = request.user.userprofile
    selected_msg = Message.objects.get(pk=mess_id)
    if not selected_msg.read_at:
        selected_msg.read_at = timezone.now()
        selected_msg.save()

    if request.method == 'POST':

        reply_form = MessageForm(data=request.POST)
        if reply_form.is_valid():

            message = reply_form.save(commit=False)
            message.sender = user
            message.recipient = reply_form.cleaned_data['recipient']
            message.save()

            log_action(user_id=request.user.id, content_type_id=get_content_type(app_name='messages',
                    model_name='message').id, object_id=message.id, object_desc=
                    'User \'%s\' has sent a reply to \'%s\'' % (request.user.username, message.recipient),
                    action_flag=1)

            return HttpResponseRedirect(reverse('to_folder', kwargs={'folder_name': 'inbox'}))

    else:
        reply_form = MessageForm(initial={'recipient': selected_msg.sender,
                                          'subject': 'Re: ' + selected_msg.subject})

    return render(request, 'messaging/message_display.html', {
        'patient': request.user, 'reply_form': reply_form, 'message': selected_msg
    })


@login_required(login_url='/login')
def msg_to_trash(request, mess_id):
    selected_msg = Message.objects.get(pk=mess_id)
    if selected_msg.recipient == request.user.userprofile:
        selected_msg.recipient_deleted_at = timezone.now()
    elif selected_msg.sender == request.user.userprofile:
        selected_msg.sender_deleted_at = timezone.now()
    selected_msg.save()
    return HttpResponseRedirect(reverse('to_folder', kwargs={'folder_name': 'inbox'}))


@login_required(login_url='/login')
def msg_to_archive(request, mess_id):
    selected_msg = Message.objects.get(pk=mess_id)
    if selected_msg.recipient == request.user.userprofile:
        selected_msg.recipient_archived = True
    elif selected_msg.sender == request.user.userprofile:
        selected_msg.sender_archived = True
    selected_msg.save()
    return HttpResponseRedirect(reverse('to_folder', kwargs={'folder_name': 'inbox'}))
