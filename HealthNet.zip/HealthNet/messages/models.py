__author__ = 'Derek Popp'

from django.db import models
from django.utils.timezone import now
from django.utils.text import Truncator
from django.utils.translation import ugettext_lazy as _


class MessageManager(models.Manager):

    def _folder(self, related, filters, order_by=None):
        qset = self.all()
        if related:
            qset = qset.select_related(*related)
        if order_by:
            qset = qset.order_by(order_by)
        if isinstance(filters, (list, tuple)):
            look_up = models.Q()
            for filter in filters:
                look_up |= models.Q(**filter)
        else:
            look_up = models.Q(**filters)
        return qset.filter(look_up)

    def inbox(self, user, related=True, **kwargs):
        related = ('sender',) if related else None
        filters = {
            'recipient': user,
            'recipient_archived': False,
            'recipient_deleted_at__isnull': True
        }
        return self._folder(related, filters, **kwargs)

    def unread_in_inbox(self, user):
        return self.inbox(user, related=False).filter(read_at__isnull=True).count()

    def sent(self, user, **kwargs):
        related = ('recipient',)
        filters = {
            'sender': user,
            'sender_archived': False,
            'sender_deleted_at__isnull': True
        }
        return self._folder(related, filters, **kwargs)

    def archives(self, user, **kwargs):
        related = ('sender', 'recipient')
        filters = ({
            'recipient': user,
            'recipient_archived': True,
            'recipient_deleted_at__isnull': True
        }, {
            'sender': user,
            'sender_archived': True,
            'sender_deleted_at__isnull': True
        })
        return self._folder(related, filters, **kwargs)

    def trash(self, user, **kwargs):
        related = ('sender', 'recipient')
        filters = ({
            'recipient': user,
            'recipient_deleted_at__isnull': False
        }, {
            'sender': user,
            'sender_deleted_at__isnull': False
        })
        return self._folder(related, filters, **kwargs)

    def mark_read(self, user, filter):
        self.filter(filter, recipient=user, read_at__isnull=True).update(read_at=now())


class Message(models.Model):
    subject = models.CharField(_("subject"), max_length=120, blank=True)
    content = models.TextField(_("body"), blank=True)
    recipient = models.ForeignKey('accounts.UserProfile', related_name='received_messages', verbose_name=_("recipient"))
    sender = models.ForeignKey('accounts.UserProfile', related_name='sent_messages', verbose_name=_("sender"))
    parent = models.ForeignKey('self', verbose_name=_("parent message"), null=True, blank=True)
    sent_at = models.DateTimeField(_("sent at"), auto_now_add=True,)
    read_at = models.DateTimeField(_("read at"), null=True, blank=True)
    recipient_archived = models.BooleanField(_("archived by recipient"), default=False)
    sender_archived = models.BooleanField(_("archived by sender"), default=False)
    recipient_deleted_at = models.DateTimeField(_("deleted by recipient at"), null=True, blank=True)
    sender_deleted_at = models.DateTimeField(_("deleted by sender at"), null=True, blank=True)

    objects = MessageManager()

    def __str__(self):
        return "{0} > {1}: {2}".format(self.sender, self.recipient, Truncator(self.subject).words(5))

    def get_subject_preview(self):
        return Truncator(self.subject).words(5)

    def get_body_preview(self):
        return Truncator(self.content).words(20)