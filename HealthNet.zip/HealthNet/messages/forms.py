__author__ = 'Derek'
from django import forms

from messages.models import Message


class MessageForm(forms.ModelForm):

    class Meta:
        model = Message
        exclude = ['sender', 'sent_at', 'read_at', 'recipient_archived', 'sender_archived',
                   'recipient_deleted_at', 'sender_deleted_at', 'parent']
