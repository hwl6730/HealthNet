from datetime import *

from django.forms import extras
from django.utils.translation import ugettext_lazy as _
from django.core.validators import RegexValidator

from .models import *
from accounts.utils import states

GENDER_CHOICES = (('M', 'Male'), ('F', 'Female'),)
YEAR_CHOICES = tuple(i for i in range(2015, 1900, -1))
STATES = tuple((key, value) for key, value in states.items())
NATIONS = (('USA', 'United States'), ('CA', 'Canada'))

phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: "
                                                               "'+999999999'. Up to 15 digits allowed.")
zip_regex = RegexValidator(regex=r'^\d{5}$', message="ZIP codes must contain 5 digits")

class UserForm(forms.ModelForm):
    """Form for creating a new user"""
    username = forms.CharField(error_messages={'required': 'Please enter an username.'})
    email = forms.EmailField(error_messages={'required': 'Please enter an email.'})
    password = forms.CharField(widget=forms.PasswordInput(), label='Password',
                               error_messages={'required': 'Please enter a password',
                                               'invalid': 'Please check to see if your passwords match'})
    password_check = forms.CharField(widget=forms.PasswordInput(), label='Password (confirm)',
                                     error_messages={'required': 'Please enter your password again.',
                                                     'invalid': 'Please check to see if your passwords match'})
    first_name = forms.CharField(error_messages={'required': 'Please enter your first name.'})
    last_name = forms.CharField(error_messages={'required': 'Please enter your last name.'})

    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'password_check',
                'first_name', 'last_name')
        widgets = {'password': forms.PasswordInput()}

    def is_valid(self):

        # run parent validation first
        valid = super(UserForm, self).is_valid()

        # if not valid, return
        if not valid:
            return valid

        p1 = self.cleaned_data['password']
        p2 = self.cleaned_data['password_check']
        if p1 != p2:
            return False

        return True


class UserProfileForm(forms.ModelForm):
    """Form for creating and modifying a UserProfile"""
    gender = forms.ChoiceField(widget=forms.Select, choices=GENDER_CHOICES,
                               error_messages={'required': "Please select a gender."})
    date_of_birth = forms.DateField(widget=extras.widgets.SelectDateWidget(years=YEAR_CHOICES), label="Date of Birth",
                                    initial=date.today())
    phone_number = forms.CharField(validators=[phone_regex], label=_("Phone Number"),
                                   error_messages={'required': 'Please enter a phone number.'})
    address = forms.CharField(label='Address', error_messages={'required': "Please enter an address."})
    city = forms.CharField(error_messages={'required': 'Please enter your city.'})
    state = forms.ChoiceField(widget=forms.Select, choices=STATES,
                              error_messages={'required': 'Please enter your state.'})
    zipcode = forms.CharField(validators=[zip_regex], error_messages={'required': 'Please enter your zipcode.'})
    country = forms.ChoiceField(widget=forms.Select, choices=NATIONS,
                                error_messages={'required': 'Please enter your country.'})

    class Meta:
        model = UserProfile
        fields = ('address', 'gender', 'date_of_birth',
                  'phone_number', 'city', 'state', 'zipcode',
                  'country')


class PatientProfileForm(forms.ModelForm):
    """Form for creating and modifying a UserProfile"""
    ice_phone = forms.CharField(validators=[phone_regex], label=_("Emergency Contact Phone Number"),
                                error_messages={'required': 'Please enter a phone number for your Emergency Contact.'})
    ice_name = forms.CharField(label="Emergency Contact",
                               error_messages={'required': 'Please enter a name for your Emergency Contact.'})
    health_insurance = forms.CharField(error_messages={'required': 'Please enter your Health Insurance Provider.'})

    class Meta:
        model = PatientProfile
        fields = ('hospital', 'health_insurance', 'ice_name',
                 'ice_phone')


class Login(forms.Form):
    username = forms.CharField(label="Username", required=True,
                               error_messages={'required': 'Please enter a username.'})
    password = forms.CharField(widget=forms.PasswordInput, label="Password", required=True,
                               error_messages={'required': 'Please enter a password.'})

    def is_valid(self):

        # run parent validation first
        valid = super(Login, self).is_valid()

        # if not valid, return
        if not valid:
            return valid

        if not authenticate(username=self.cleaned_data['username'],
                            password=self.cleaned_data['password']):
            self._errors['invalid_login'] = self.error_class(['Invalid login information.'])
            return False
        return True

