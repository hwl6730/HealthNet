from django.db import models
from django.contrib.auth.forms import *

from hospitals.models import Hospital
from messages.models import Message


GENDER_CHOICES = (
    ('M', 'Male'), ('F', 'Female'),
)


class UserProfile(models.Model):
    """Basic profile information for users"""
    user = models.OneToOneField(User)
    address = models.CharField(blank=True, max_length=50)
    date_of_birth = models.DateField()
    phone_number = models.CharField(max_length=11)
    city = models.CharField(max_length=120)
    state = models.CharField(max_length=50)
    zipcode = models.CharField(max_length=33)
    country = models.CharField(max_length=150)
    gender = models.CharField(max_length=4, choices=GENDER_CHOICES)

    def __str__(self):
        return self.user.first_name + ' ' + self.user.last_name + ' (' + self.user.username + ')'

    def get_unread_messages(self):
        return Message.objects.unread_in_inbox(self)

    def get_inbox_preview(self):
        return Message.objects.inbox(self).order_by('-sent_at')[:3]

    def get_inbox(self):
        return Message.objects.inbox(self).order_by('-sent_at')

    def get_sent(self):
        return Message.objects.sent(self).order_by('-sent_at')

    def get_archived(self):
        return Message.objects.archives(self).order_by('-sent_at')

    def get_trash(self):
        return Message.objects.trash(self).order_by('-sent_at')


class NurseProfile(models.Model):
    """Nurse profile information"""
    user = models.OneToOneField(User)
    hospital = models.ManyToManyField(Hospital)

    def __str__(self):
        return "Nurse " + self.user.first_name + ' ' + self.user.last_name


class PatientProfile(models.Model):
    """Patient profile information"""
    user = models.OneToOneField(User)
    doctor = models.ForeignKey('DoctorProfile', blank=True, null=True)
    hospital = models.ForeignKey('hospitals.Hospital', blank=True, null=True)
    health_insurance = models.CharField(blank=True, max_length=50)
    ice_name = models.CharField(blank=True, max_length=50)
    ice_phone = models.CharField(max_length=11)
    admitted = models.BooleanField(default=False)
    ice_user = models.ForeignKey('UserProfile', blank=True, null=True)

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name


class DoctorProfile(models.Model):
    """Doctor profile information"""
    user = models.OneToOneField(User)
    nurses = models.ManyToManyField(NurseProfile, blank=True, null=True)
    hospital = models.ForeignKey('hospitals.Hospital', blank=True, null=True)

    def __str__(self):
        return "Doctor " + self.user.first_name + ' ' + self.user.last_name


class Transfer(models.Model):
    patient = models.ForeignKey('accounts.PatientProfile')
    newHospital = models.ForeignKey('hospitals.Hospital')
    created_at = models.DateTimeField(auto_now_add=True)