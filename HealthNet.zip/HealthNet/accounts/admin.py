from django.contrib import admin

from admin.models import AdminProfile
from accounts.models import *
from documents.models import Document


HOSPITAL_CHOICES = (
    ('STR', 'Strong Memorial Hospital'),
    ('RGH', 'Rochester General Hospital'),
    ('HIH', 'Highland Hospital'),
    ('UNI', 'Unity Hospital'),
    ('CSH', 'Clifton Springs Hospital')
)

admin.site.register(AdminProfile)
admin.site.register(UserProfile)
admin.site.register(Document)
admin.site.register(PatientProfile)
admin.site.register(DoctorProfile)
admin.site.register(NurseProfile)