from django.test import TestCase

from accounts.forms import *



# Create your tests here.

class UserTestCase(TestCase):
    def setUp(self):
        User.objects.create_user(username="test1", password="pass", first_name="John", last_name="Doe")
        pass

    def test_user_exists(self):
        self.assertNotEqual(User.objects.get(username="test1"), None)

    def test_UserForm_valid(self):
        test_data = {'username': 'p1',
                     'password': 'x',
                     'password_check': 'x',
                     'email': 'deadpool@marvel.com',
                     'first_name': "Wade",
                     'last_name': "Wilson"}
        user_form = UserForm(test_data)
        self.assertTrue(user_form.is_valid())
        del test_data['password_check']
        del user_form.cleaned_data['password_check']
        user = User(**user_form.cleaned_data)
        for key, value in test_data.items():
            self.assertEqual(getattr(user, key), value)

    def test_UserForm_invalid_pass_mismatch(self):
        test_data = {'username': 'p1',
                     'password': 'x',
                     'password_check': 'j',
                     'email': 'deadpool@marvel.com',
                     'first_name': "Wade",
                     'last_name': "Wilson"}
        user_form = UserForm(test_data)
        self.assertFalse(user_form.is_valid())

    def test_UserForm_invalid_email_at(self):
        test_data = {'username': 'p1',
                     'password': 'x',
                     'password_check': 'x',
                     'email': 'deadpoolmarvel.com',
                     'first_name': "Wade",
                     'last_name': "Wilson"}
        user_form = UserForm(test_data)
        self.assertFalse(user_form.is_valid())

    def test_UserForm_invalid_email_com(self):
        test_data = {'username': 'p1',
                     'password': 'x',
                     'password_check': 'x',
                     'email': 'deadpool@marvel',
                     'first_name': "Wade",
                     'last_name': "Wilson"}
        user_form = UserForm(test_data)
        self.assertFalse(user_form.is_valid())


class UserProfileTestCase(TestCase):
    def test_UserProfileForm_valid(self):  # test a valid model
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '14623',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertTrue(user_profile_form.is_valid())
        user_profile = UserProfile(**user_profile_form.cleaned_data)
        for key, value in test_data.items():
            self.assertEqual(getattr(user_profile, key), value)
            
    def test_UserProfileForm_invalid_nogender(self):
        test_data = {'gender': None,
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())
        
    def test_UserProfileForm_invalid_nodob(self):
        test_data = {'gender': 'M',
                     'date_of_birth': None,
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_nophone(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())
        
    def test_UserProfileForm_invalid_noaddress(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_nocity(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': '',
                     'state': 'NY',
                     'zipcode': '123245',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_nostate(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': None,
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())
        
    def test_UserProfileForm_invalid_nozip(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_zipletters(self):  # letters in zip
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': 'abc12',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_ziplong(self):  # zip > 5 numbers
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '1' * 10,
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_zipshort(self):  # zip < 5 numbers
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '1' * 10,
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_phone_alpha(self):  # Letters in phone number
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': 'abc1223',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': '12345',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_phone_numshort(self):  # not enough digits
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': 'abc123',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())

    def test_UserProfileForm_invalid_phone_numlong(self):  # too many digits
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '1234567890123',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': 'abc123',
                     'country': "USA"}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())
        
    def test_UserProfileForm_invalid_nocountry(self):
        test_data = {'gender': 'M',
                     'date_of_birth': date.today(),
                     'phone_number': '123456789',
                     'address': '1234 Nowhere',
                     'city': 'Rochester',
                     'state': 'NY',
                     'zipcode': 'abc12',
                     'country': ''}
        user_profile_form = UserProfileForm(test_data)
        self.assertFalse(user_profile_form.is_valid())


class PatientProfileTestCase(TestCase):
    def test_PatientProfileForm_valid(self):  # test a valid model
        test_data = {'ice_phone': '123456789',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertTrue(patient_profile_form.is_valid())
        patient_profile = PatientProfile(**patient_profile_form.cleaned_data)
        for key, value in test_data.items():
            self.assertEqual(getattr(patient_profile, key), value)

    def test_PatientProfileForm_invalid_icephone_numA(self):  # not enough digits
        test_data = {'ice_phone': '123456',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())

    def test_PatientProfileForm_invalid_icephone_numB(self):  # too many digits
        test_data = {'ice_phone': '1234567890123',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())

    def test_PatientProfileForm_invalid_nophone(self):
        test_data = {'ice_phone': '',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())

    def test_PatientProfileForm_invalid_noname(self):
        test_data = {'ice_phone': '123456790',
                     'ice_name': '',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())

    def test_PatientProfileForm_invalid_nohi(self):
        test_data = {'ice_phone': '123456790',
                     'ice_name': 'Rescue',
                     'health_insurance': '',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())

    def test_PatientProfileForm_invalid_icephone_alpha(self):  # letters in phone number
        test_data = {'ice_phone': 'abc123',
                     'ice_name': 'Rescue',
                     'health_insurance': 'Some Health Care',
                     'hospital': None}
        patient_profile_form = PatientProfileForm(test_data)
        self.assertFalse(patient_profile_form.is_valid())