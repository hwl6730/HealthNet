__author__ = 'Allen Sanford'

from django import template

register = template.Library()


@register.filter(name='get_hospitals')
def get_hospitals(var, nurse):
    hos = ""
    for h in nurse.hospital.all():
        hos += ", " + h.name
    var = hos[2:]
    return var