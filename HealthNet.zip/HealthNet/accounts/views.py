from django.contrib.auth.decorators import login_required
from django.shortcuts import render_to_response, render
from django.http import HttpResponse
from django.template import RequestContext
from django.contrib.auth import login
from django.contrib.auth.models import Group
from django.http import HttpResponseRedirect
from django.contrib.auth import logout as user_lo
from django.contrib.auth.decorators import user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from accounts.forms import *
from accounts.models import *
from action_logging.models import log_action, get_content_type
from admin.models import AdminProfile


def register(request):
    """View for registering a patient"""
    context = RequestContext(request)

    registered = False

    postdata = request.POST.copy()

    if request.method == 'POST':

        user_form = UserForm(data=request.POST)
        profile_form = UserProfileForm(data=request.POST)
        patient_form = PatientProfileForm(data=request.POST)

        if profile_form.is_valid() and user_form.is_valid() and patient_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()

            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()

            patient_info = patient_form.save(commit=False)
            patient_info.user = user
            patient_info.save()

            registered = True

            g = Group.objects.get_or_create(name='Patients')

            if g:
                group = g[0]
                group.user_set.add(user)

            log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                       object_id=user.id, object_desc='User \'%s\' has registered with HealthNet.' % user.username,
                       action_flag=1)

            # Auto assign doctors with fewest number of patients in the hospital.
            if len(patient_info.hospital.doctorprofile_set.all()) > 0:
                assigned_doctor = \
                    sorted(patient_info.hospital.doctorprofile_set.all(),
                        key=lambda doc: len(doc.patientprofile_set.all()))[0]

                if assigned_doctor:
                    user.patientprofile.doctor = assigned_doctor
                else:
                    user.patientprofile.doctor = None
            else:
                user.patientprofile.doctor = None

            # Check to see if ICE is a user
            if len(user.patientprofile.ice_name.split()) > 1:
                ice_first = user.patientprofile.ice_name.split()[0]
                ice_last = user.patientprofile.ice_name.split()[1]
                ice_phone = user.patientprofile.ice_phone

                for potential in UserProfile.objects.all():
                    if potential.user.first_name == ice_first \
                            and potential.user.last_name == ice_last \
                            and potential.phone_number == ice_phone:
                        user.patientprofile.ice_user = potential
                patient_info.save()

            # Auto login on completion.
            user.backend = 'django.contrib.auth.backends.ModelBackend'
            login(request, user)

            return HttpResponseRedirect('/home')
    else:
        user_form = UserForm()
        profile_form = UserProfileForm()
        patient_form = PatientProfileForm()

    return render_to_response('login/register.html', {'patient_form': patient_form, 'user_form': user_form,
                                                      'profile_form': profile_form, 'registered': registered}, context)


@user_passes_test(lambda u: not u.groups.filter(name='Patients').exists(), login_url='/home/')
@login_required(login_url='/login')
def change_info_staff(request, p_id):
    """Allows staff to change a patient's profile"""
    # User Object
    patient = User.objects.get(id=p_id)
    try:
        nurse = request.user.nurseprofile
    except NurseProfile.DoesNotExist:
        nurse = None

    if nurse and (patient.patientprofile.hospital not in nurse.hospital.all()):
        return HttpResponseRedirect('/staff/patients')

    if request.method == 'POST':
        upform = PatientProfileForm(request.POST, instance=patient.patientprofile)

        if upform.is_valid():
            up = upform.save(commit=False)
            up.user = patient
            up.save()

    else:
        upform = PatientProfileForm(instance=patient.patientprofile)

    # Load upload_documents for the list page
    documents = patient.patientprofile.document_set.all()
    prescriptions = patient.patientprofile.prescription_set.all()

    paginator = Paginator(prescriptions, 5)
    page = request.GET.get('page')

    try:
        prescriptions_list = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        prescriptions_list = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        prescriptions_list = paginator.page(paginator.num_pages)

    doc = False
    if request.user.groups.filter(name='Doctors').exists():
        doc = True
    if request.user.is_superuser:
        return render(request, 'admin/admin_edit_profile.html',
                  {'patient': patient.patientprofile, 'u_info': upform, 'p_id': p_id,
                   'doc_bool': doc, 'user': request.user,
                   'documents': documents, 'prescriptions': prescriptions_list})

    return render(request, 'staff_pages/staff_edit_profile.html',
                  {'patient': patient.patientprofile, 'u_info': upform, 'p_id': p_id,
                   'doc_bool': doc, 'doctor': request.user, 'nurse': request.user,
                   'documents': documents, 'prescriptions': prescriptions_list})


@login_required(login_url='/login')
def patient_med(request):
    """shows the patient's medical information"""
    user = request.user
    context = RequestContext(request)

    return render_to_response(
        'staff_pages/patient_meds.html', {'user': user.patientprofile, 'patient': user},
        context
    )


@login_required(login_url='/login')
def change_info(request):
    """Allows a patient to update their profile info"""
    user = request.user
    context = RequestContext(request)
    if request.method == 'POST':
        upform = UserProfileForm(request.POST, instance=user.get_profile())

        if upform.is_valid():
            up = upform.save(commit=False)
            up.user = request.user
            up.save()
            log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                       object_id=user.id,
                       object_desc='User \'%s\' has changed their account information.' % user.username,
                       action_flag=2)
    else:
        upform = UserProfileForm(instance=user.get_profile())

    if user.groups.filter(name='Patients').exists():
        return render_to_response('general/change.html', {'user': user, 'u_info': upform, 'patient': user}, context)
    elif user.is_superuser:
        return render_to_response('admin/admin_change.html', {'user': user, 'u_info': upform, 'admin': user}, context)
    elif user.groups.filter(name='Doctors').exists():
        return render_to_response('staff_pages/staff_change.html', {'user': user, 'u_info': upform, 'doctor': user,
                                                                    'doc_bool': True}, context)
    elif user.groups.filter(name='Nurses').exists():
        return render_to_response('staff_pages/staff_change.html', {'user': user, 'u_info': upform, 'nurse': user,
                                                                    'doc_bool': False}, context)


def user_login(request):
    """Logs a user in to the correct home page"""
    context = RequestContext(request)

    if request.method == 'POST':
        l_form = Login(request.POST)

        if l_form.is_valid():
            user = authenticate(username=l_form.cleaned_data['username'],
                                password=l_form.cleaned_data['password'])
            if user.is_active:
                login(request, user)
                if user.is_superuser:
                    try:
                        admin = user.adminprofile
                    except AdminProfile.DoesNotExist:
                        admin = None
                    log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                           object_id=user.id, object_desc='\'%s\' has logged in.' % (admin if admin else user.username),
                           action_flag=4)
                    return HttpResponseRedirect('/staff/admin/')
                elif user.groups.filter(name='Patients').exists():
                    log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=user.id, object_desc='Patient \'%s\' has logged in.' % user.patientprofile,
                               action_flag=4)
                    return HttpResponseRedirect('/home/')
                elif user.groups.filter(name='Doctors').exists():
                    log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=user.id, object_desc='\'%s\' has logged in.' % user.doctorprofile,
                               action_flag=4)
                    return HttpResponseRedirect('/staff/doctor/')
                elif user.groups.filter(name='Nurses').exists():
                    log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                               object_id=user.id, object_desc='\'%s\' has logged in.' % user.nurseprofile,
                               action_flag=4)
                    return HttpResponseRedirect('/staff/nurse/')
                else:
                    return HttpResponseRedirect('/')

            else:
                # An inactive account was used - no logging in!
                return HttpResponse("Your account is disabled. Please contact a system administrator.")
        else:
            return render_to_response('login/login.html', {'l_form': l_form}, context)
    else:
        l_form = Login()
        return render_to_response('login/login.html', {'l_form': l_form}, context)


@login_required(login_url='/login')
def logout(request):
    """Logs a user out"""
    user = request.user
    if user.is_superuser:
        try:
            admin = user.adminprofile
        except AdminProfile.DoesNotExist:
            admin = None
        log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
               object_id=user.id, object_desc='\'%s\' has logged out.' % (admin if admin else user.username),
               action_flag=4)
    elif user.groups.filter(name='Patients').exists():
        log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                   object_id=user.id, object_desc='Patient \'%s\' has logged out.' % user.patientprofile,
                   action_flag=4)
    elif user.groups.filter(name='Doctors').exists():
        log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                   object_id=user.id, object_desc='\'%s\' has logged out.' % user.doctorprofile,
                   action_flag=4)
    elif user.groups.filter(name='Nurses').exists():
        log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                   object_id=user.id, object_desc='\'%s\' has logged out.' % user.nurseprofile,
                   action_flag=4)
    else:
        log_action(user_id=user.id, content_type_id=get_content_type(app_name='auth', model_name='user').id,
                   object_id=user.id, object_desc='User \'%s\' has logged out.' % user.username, action_flag=4)
    user_lo(request)
    return HttpResponseRedirect('/')













