__author__ = 'Allen Sanford'

#/user routes here

# urlpatterns = patterns('',
#     url(r'^accounts/', 'django.contrib.auth.views.accounts', name="accounts"),
#     url(r'^home/logout_page/$', views.logout_page, name="logout"),
#     url(r'^accounts/accounts/$', 'django.contrib.auth.views.accounts', name="account accounts"), # If user is not accounts it will redirect to accounts page
#     url(r'^register/$', views.register, name='register'),
#     url(r'^register/success/$', views.register_success, name='register success'),
#     url(r'^accounts/home$', views.register_success, name='register success'),
# )
